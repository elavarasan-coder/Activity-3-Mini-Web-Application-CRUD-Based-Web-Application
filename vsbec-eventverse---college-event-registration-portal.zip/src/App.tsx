import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Footer } from './components/Footer';
import { ToastContainer } from './components/ToastContainer';

// Views
import { HomeView } from './views/HomeView';
import { EventsView } from './views/EventsView';
import { AdminDashboardView } from './views/AdminDashboardView';
import { EventManagementView } from './views/EventManagementView';
import { StudentManagementView } from './views/StudentManagementView';
import { RegistrationManagementView } from './views/RegistrationManagementView';
import { MyEventsView } from './views/MyEventsView';
import { NotificationsView } from './views/NotificationsView';
import { AdminProfileView } from './views/AdminProfileView';
import { LoginView } from './views/LoginView';
import { ProjectDocsView } from './views/ProjectDocsView';
import { DigitalPassView } from './views/DigitalPassView';

const AppContent: React.FC = () => {
  const { currentView } = useApp();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const renderCurrentView = () => {
    switch (currentView) {
      case 'home':
        return <HomeView />;
      case 'events':
        return <EventsView />;
      case 'dashboard':
        return <AdminDashboardView />;
      case 'events-manage':
        return <EventManagementView />;
      case 'students-manage':
        return <StudentManagementView />;
      case 'registrations-manage':
        return <RegistrationManagementView />;
      case 'my-events':
        return <MyEventsView />;
      case 'notifications':
        return <NotificationsView />;
      case 'profile':
        return <AdminProfileView />;
      case 'login':
        return <LoginView />;
      case 'docs':
        return <ProjectDocsView />;
      case 'digital-pass':
        return <DigitalPassView />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0B1026] text-[#FFFDF7] selection:bg-[#7C3AED] selection:text-white antialiased font-sans">
      
      {/* Top Navbar */}
      <Navbar onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />

      {/* Main Layout Body */}
      <div className="flex-1 flex w-full">
        
        {/* Navigation Sidebar */}
        <Sidebar 
          isOpen={isSidebarOpen} 
          onClose={() => setIsSidebarOpen(false)} 
        />

        {/* Dynamic View Canvas */}
        <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {renderCurrentView()}
        </main>

      </div>

      {/* Persistent Footer */}
      <Footer />

      {/* Global Toast Alerts */}
      <ToastContainer />

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
