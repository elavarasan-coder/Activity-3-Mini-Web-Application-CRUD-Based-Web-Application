import React, { useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Printer, Download, ShieldCheck, QrCode, Sparkles, 
  Calendar, MapPin, User, Hash, CheckCircle2, Ticket,
  Share2, Check, Clock, School
} from 'lucide-react';
import { Registration } from '../types';

interface DigitalEventPassProps {
  registrationOverride?: Registration | null;
}

export const DigitalEventPass: React.FC<DigitalEventPassProps> = ({ registrationOverride }) => {
  const { registrations, selectedPassRegistration, setSelectedPassRegistration, auth, events, showToast } = useApp();
  const printRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);

  // Determine current pass:
  const studentRegs = auth.role === 'student'
    ? registrations.filter(r => r.registerNumber.toLowerCase() === auth.user?.registerNumber?.toLowerCase())
    : registrations;

  const currentReg: Registration | null = 
    registrationOverride ||
    selectedPassRegistration ||
    studentRegs.find(r => r.status === 'APPROVED') ||
    registrations[0] ||
    null;

  const eventDetails = currentReg ? events.find(e => e.id === currentReg.eventId) : null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    window.print();
    showToast('Choose "Save as PDF" in your print preview window to download pass.', 'info');
  };

  const handleShare = () => {
    if (navigator.clipboard && currentReg) {
      navigator.clipboard.writeText(
        `🎟️ VSBEC EVENTVERSE PASS: ${currentReg.eventName}\nParticipant: ${currentReg.studentName} (${currentReg.registerNumber})\nDate: ${currentReg.eventDate}\nVenue: ${currentReg.eventVenue}\nPass ID: ${currentReg.registrationId}`
      );
      setCopied(true);
      showToast('Event Pass details copied to clipboard!', 'success');
      setTimeout(() => setCopied(false), 3000);
    }
  };

  if (!currentReg) {
    return (
      <div className="p-10 text-center bg-[#21113D]/40 border border-violet-500/20 rounded-3xl max-w-lg mx-auto my-12">
        <Ticket className="w-12 h-12 text-[#F4D06F] mx-auto mb-3 opacity-60" />
        <h3 className="text-lg font-bold text-white font-heading">No Event Pass Found</h3>
        <p className="text-xs text-neutral-300 mt-2">
          You have not registered for any events yet, or your registration is pending confirmation by the event administrator.
        </p>
      </div>
    );
  }

  // Deterministic QR Code pattern generator from Pass Registration ID
  const generateQrMatrix = (idStr: string) => {
    const size = 17;
    const matrix: boolean[][] = [];
    let hash = 0;
    for (let i = 0; i < idStr.length; i++) {
      hash = (hash << 5) - hash + idStr.charCodeAt(i);
      hash |= 0;
    }

    for (let r = 0; r < size; r++) {
      const row: boolean[] = [];
      for (let c = 0; c < size; c++) {
        // Corner markers (3 standard finder patterns)
        const isCorner = 
          (r < 5 && c < 5) || 
          (r < 5 && c >= size - 5) || 
          (r >= size - 5 && c < 5);

        if (isCorner) {
          const isOuterBorder = 
            r === 0 || r === 4 || c === 0 || c === 4 ||
            r === 0 || r === 4 || c === size - 1 || c === size - 5 ||
            r === size - 1 || r === size - 5 || c === 0 || c === 4;
          const isInnerSquare = 
            (r >= 1 && r <= 3 && c >= 1 && c <= 3) ||
            (r >= 1 && r <= 3 && c >= size - 4 && c <= size - 2) ||
            (r >= size - 4 && r <= size - 2 && c >= 1 && c <= 3);
          row.push(isOuterBorder || isInnerSquare);
        } else {
          // pseudo-random deterministic distribution based on hash
          const val = Math.abs(Math.sin((r * size + c + hash) * 12345));
          row.push(val > 0.44);
        }
      }
      matrix.push(row);
    }
    return matrix;
  };

  const qrMatrix = generateQrMatrix(currentReg.registrationId);

  return (
    <div className="space-y-6">
      
      {/* Top selector if multiple registrations exist */}
      {studentRegs.length > 1 && (
        <div className="no-print flex items-center justify-between bg-[#21113D]/40 p-3 rounded-2xl border border-violet-500/20 max-w-2xl mx-auto">
          <span className="text-xs font-semibold text-neutral-300">
            Select Confirmed Pass:
          </span>
          <select
            value={currentReg.id}
            onChange={(e) => {
              const selected = registrations.find(r => r.id === e.target.value);
              if (selected) setSelectedPassRegistration(selected);
            }}
            className="bg-[#0B1026] text-[#F4D06F] text-xs font-semibold px-3 py-1.5 rounded-xl border border-violet-500/30 focus:border-[#F4D06F] outline-none"
          >
            {studentRegs.map(r => (
              <option key={r.id} value={r.id}>
                {r.eventName} ({r.registrationId}) - {r.status}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Action Buttons: Print, Download, Share */}
      <div className="no-print flex flex-wrap items-center justify-center gap-3">
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] text-white font-extrabold text-xs uppercase tracking-wider shadow-xl shadow-violet-950/60 border border-violet-400/40 hover:border-[#F4D06F] hover:scale-[1.02] transition-all"
        >
          <Printer className="w-4 h-4 text-[#F4D06F]" />
          <span>Print Pass</span>
        </button>

        <button
          onClick={handleDownload}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#21113D]/60 hover:bg-[#21113D] text-white font-bold text-xs uppercase tracking-wider border border-violet-500/30 hover:border-violet-400 transition-all"
        >
          <Download className="w-4 h-4 text-violet-300" />
          <span>Download PDF</span>
        </button>

        <button
          onClick={handleShare}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-neutral-200 font-bold text-xs uppercase tracking-wider border border-violet-500/20 hover:border-violet-400 transition-all"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4 text-[#F4D06F]" />}
          <span>{copied ? 'Copied' : 'Share Pass'}</span>
        </button>
      </div>

      {/* ULTRA-PREMIUM DIGITAL EVENT PASS */}
      <div 
        ref={printRef}
        id="printable-event-pass"
        className="relative max-w-xl mx-auto rounded-3xl bg-gradient-to-b from-[#21113D] via-[#0B1026] to-[#0B1026] border-2 border-violet-500/40 shadow-2xl shadow-purple-950/80 text-white overflow-hidden p-6 sm:p-8 transition-all"
      >
        {/* Security Watermark Background */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none opacity-5 rotate-[-25deg]">
          <span className="text-4xl sm:text-5xl font-black tracking-widest text-[#F4D06F] uppercase">
            VSBEC OFFICIAL EVENT PASS
          </span>
        </div>

        {/* Ambient Top Glow */}
        <div className="absolute top-0 right-0 -mt-16 -mr-16 w-56 h-56 rounded-full bg-[#C026D3]/20 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 w-56 h-56 rounded-full bg-[#7C3AED]/20 blur-3xl pointer-events-none" />

        {/* Header: College Name & Project Title */}
        <div className="flex items-center justify-between border-b border-violet-500/30 pb-4 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#7C3AED] via-[#C026D3] to-[#F4D06F] p-0.5 shadow-lg shadow-violet-900/40 flex items-center justify-center">
              <div className="w-full h-full bg-[#0B1026] rounded-[14px] flex items-center justify-center font-black text-sm text-[#F4D06F]">
                VSB
              </div>
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black tracking-wider font-heading text-white">
                V.S.B. ENGINEERING COLLEGE, KARUR
              </h2>
              <div className="text-[10px] font-extrabold uppercase tracking-widest bg-gradient-to-r from-violet-300 via-fuchsia-300 to-[#F4D06F] bg-clip-text text-transparent">
                VSBEC EVENTVERSE • DIGITAL EVENT PASS
              </div>
            </div>
          </div>

          <div className="text-right">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>CONFIRMED</span>
            </span>
          </div>
        </div>

        {/* Subtitle Tagline Strip */}
        <div className="my-4 text-center bg-gradient-to-r from-violet-950/80 via-[#21113D] to-violet-950/80 py-2 px-4 rounded-2xl border border-violet-500/30 shadow-inner relative z-10">
          <div className="text-xs font-black text-[#F4D06F] uppercase tracking-widest font-heading">
            OFFICIAL GATE ENTRY PASS
          </div>
          <div className="text-[10px] text-violet-200/90 tracking-wider uppercase font-medium">
            Connect • Create • Participate • Celebrate
          </div>
        </div>

        {/* Event Name & Details Box */}
        <div className="mb-5 p-4 rounded-2xl bg-white/[0.03] border border-violet-500/30 relative z-10">
          <div className="flex items-center justify-between text-xs text-[#F4D06F] font-bold uppercase tracking-wider mb-1">
            <span>Event Category</span>
            <span className="px-2 py-0.5 rounded-full bg-violet-600/30 text-violet-300 text-[10px] border border-violet-500/40">
              {currentReg.eventCategory || 'Technical'}
            </span>
          </div>
          <h3 className="text-base sm:text-lg font-black text-white leading-snug">
            {currentReg.eventName}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3 pt-3 border-t border-violet-500/20 text-xs text-neutral-300">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-fuchsia-400 shrink-0" />
              <span>Date: <strong className="text-white">{currentReg.eventDate}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#F4D06F] shrink-0" />
              <span className="truncate">Venue: <strong className="text-white">{currentReg.eventVenue}</strong></span>
            </div>
          </div>
        </div>

        {/* Student Credential Grid & QR Code */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center bg-[#0B1026]/90 p-4 rounded-2xl border border-violet-500/30 relative z-10">
          
          {/* Student Info */}
          <div className="sm:col-span-2 space-y-2.5 text-xs">
            <div>
              <span className="text-[10px] text-violet-400 uppercase tracking-wider font-bold block">
                Participant Name
              </span>
              <span className="text-sm font-black text-white tracking-wide">
                {currentReg.studentName}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-[10px] text-violet-400 uppercase tracking-wider font-bold block">
                  Register Number
                </span>
                <span className="font-mono-num font-bold text-[#F4D06F]">
                  {currentReg.registerNumber}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-violet-400 uppercase tracking-wider font-bold block">
                  Department & Class
                </span>
                <span className="font-semibold text-neutral-200">
                  {currentReg.department} ({currentReg.year || '2nd Year'})
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-violet-500/20">
              <div>
                <span className="text-[10px] text-violet-400 uppercase tracking-wider font-bold block">
                  Pass ID / Reg ID
                </span>
                <span className="font-mono-num font-black text-fuchsia-400 text-xs tracking-wider">
                  {currentReg.registrationId}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-violet-400 uppercase tracking-wider font-bold block">
                  Entry Status
                </span>
                <span className="inline-flex items-center gap-1 font-bold text-[11px] text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>CONFIRMED</span>
                </span>
              </div>
            </div>
          </div>

          {/* QR Code Container */}
          <div className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white text-black shadow-xl ring-2 ring-[#F4D06F]">
            <svg 
              className="w-24 h-24" 
              viewBox={`0 0 ${qrMatrix.length} ${qrMatrix.length}`}
              shapeRendering="crispEdges"
            >
              {qrMatrix.map((row, rIdx) =>
                row.map((filled, cIdx) => (
                  <rect
                    key={`${rIdx}-${cIdx}`}
                    x={cIdx}
                    y={rIdx}
                    width={1}
                    height={1}
                    fill={filled ? '#0B1026' : '#ffffff'}
                  />
                ))
              )}
            </svg>
            <span className="text-[9px] font-mono-num font-extrabold text-neutral-900 mt-1 tracking-tight">
              {currentReg.registrationId}
            </span>
          </div>

        </div>

        {/* Security & Verification Footer */}
        <div className="mt-5 pt-4 border-t border-violet-500/30 flex flex-col sm:flex-row items-center justify-between text-[10px] text-neutral-400 gap-2 relative z-10">
          <div>
            <span>Authorized by: </span>
            <strong className="text-[#F4D06F]">ELAVARASAN R (Event Administrator)</strong>
          </div>
          <div className="italic text-violet-300">
            Scan QR code at Helpdesk / Gate Entrance with College ID Card
          </div>
        </div>

      </div>

    </div>
  );
};
