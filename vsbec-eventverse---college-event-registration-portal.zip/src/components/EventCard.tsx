import React from 'react';
import { EventItem } from '../types';
import { 
  Calendar, MapPin, Clock, Users, ArrowRight, 
  Sparkles, CheckCircle, AlertTriangle 
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface EventCardProps {
  event: EventItem;
  onRegister: (event: EventItem) => void;
  onViewDetails?: (event: EventItem) => void;
}

export const EventCard: React.FC<EventCardProps> = ({ event, onRegister, onViewDetails }) => {
  const { registrations, auth, theme } = useApp();

  const isDark = theme === 'dark';

  const isAlreadyRegistered = Boolean(
    auth.isAuthenticated &&
    auth.user?.registerNumber &&
    registrations.some(
      r => r.eventId === event.id && 
      r.registerNumber.toLowerCase() === auth.user?.registerNumber.toLowerCase()
    )
  );

  const today = new Date().toISOString().split('T')[0];
  const isPastDeadline = event.registrationDeadline < today;
  const isFull = event.currentParticipants >= event.maxParticipants;
  const pct = Math.min(100, Math.round((event.currentParticipants / event.maxParticipants) * 100));

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Technical':
      case 'Symposium':
        return 'bg-violet-950/80 text-violet-300 border-violet-500/40';
      case 'Hackathon':
        return 'bg-fuchsia-950/80 text-fuchsia-300 border-fuchsia-500/40';
      case 'Workshop':
        return 'bg-indigo-950/80 text-indigo-300 border-indigo-500/40';
      case 'Cultural':
        return 'bg-pink-950/80 text-pink-300 border-pink-500/40';
      case 'Sports':
        return 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40';
      case 'Innovation':
        return 'bg-amber-950/80 text-[#F4D06F] border-amber-500/40';
      case 'Seminar':
        return 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40';
      default:
        return 'bg-purple-950/80 text-purple-300 border-purple-500/40';
    }
  };

  return (
    <div className={`group relative rounded-3xl backdrop-blur-xl border transition-all duration-300 flex flex-col justify-between overflow-hidden ${
      isDark 
        ? 'bg-[#0B1026]/80 border-violet-500/25 hover:border-[#F4D06F] hover:shadow-2xl hover:shadow-purple-950/60' 
        : 'bg-white border-violet-200 hover:border-violet-400 hover:shadow-xl'
    }`}>
      
      {/* Image Banner */}
      <div className="relative h-48 w-full overflow-hidden bg-[#21113D]">
        <img
          src={event.image}
          alt={event.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 filter brightness-95 group-hover:brightness-105"
          loading="lazy"
        />
        <div className={`absolute inset-0 bg-gradient-to-t ${
          isDark ? 'from-[#0B1026] via-[#0B1026]/40 to-transparent' : 'from-white via-transparent to-transparent'
        }`} />

        {/* Category Badge & Featured Pill */}
        <div className="absolute top-3 left-3 flex items-center gap-2">
          <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider border shadow-md backdrop-blur-md ${getCategoryColor(event.category)}`}>
            {event.category}
          </span>
          {event.featured && (
            <span className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-[#F4D06F] to-amber-400 text-[#0B1026] shadow-md">
              <Sparkles className="w-3 h-3 text-[#0B1026]" />
              <span>Featured</span>
            </span>
          )}
        </div>

        {/* Department Tag */}
        <div className="absolute top-3 right-3">
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#0B1026]/80 text-violet-200 border border-violet-500/30 backdrop-blur-md">
            {event.department}
          </span>
        </div>

        {/* Event ID badge */}
        <div className="absolute bottom-2 right-3 text-[10px] font-mono-num text-neutral-400 bg-[#0B1026]/80 px-2 py-0.5 rounded-md border border-violet-500/20">
          {event.eventId}
        </div>
      </div>

      {/* Card Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div>
          <h3 className="text-base sm:text-lg font-black group-hover:text-[#F4D06F] transition-colors line-clamp-2 font-heading leading-tight text-white">
            {event.name}
          </h3>

          <p className="text-xs text-neutral-300 mt-2 line-clamp-2 leading-relaxed">
            {event.description}
          </p>
        </div>

        {/* Date, Time, Venue */}
        <div className="space-y-2 py-2 border-y border-violet-500/20 text-xs text-neutral-300">
          <div className="flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5 text-fuchsia-400 shrink-0" />
            <span className="font-semibold text-white">{event.date}</span>
            <span className="text-neutral-500">•</span>
            <Clock className="w-3.5 h-3.5 text-violet-400 shrink-0" />
            <span className="text-neutral-300">{event.startTime}</span>
          </div>

          <div className="flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-[#F4D06F] shrink-0" />
            <span className="text-neutral-300 truncate font-medium">{event.venue}</span>
          </div>
        </div>

        {/* Capacity & Progress */}
        <div>
          <div className="flex justify-between items-center text-[11px] mb-1.5 font-semibold">
            <span className="text-neutral-400 flex items-center gap-1">
              <Users className="w-3 h-3 text-violet-400" />
              <span>Available Seats:</span>
            </span>
            <span className="font-mono-num text-neutral-200">
              <strong className={isFull ? 'text-rose-400' : 'text-[#F4D06F]'}>
                {Math.max(0, event.maxParticipants - event.currentParticipants)}
              </strong>
              <span className="text-neutral-500"> / {event.maxParticipants} total</span>
            </span>
          </div>

          <div className="h-1.5 w-full bg-[#21113D] rounded-full overflow-hidden border border-violet-500/20">
            <div 
              className={`h-full transition-all duration-500 ${
                isFull 
                  ? 'bg-rose-500' 
                  : pct > 85 
                  ? 'bg-[#F4D06F]' 
                  : 'bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#F4D06F]'
              }`}
              style={{ width: `${pct}%` }}
            />
          </div>

          <div className="flex justify-between items-center text-[10px] text-neutral-400 mt-1">
            <span>Deadline: {event.registrationDeadline}</span>
            {isPastDeadline ? (
              <span className="text-rose-400 font-bold">Closed</span>
            ) : isFull ? (
              <span className="text-[#F4D06F] font-bold">Housefull</span>
            ) : (
              <span className="text-emerald-400 font-bold">Registration Open</span>
            )}
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-2">
          {isAlreadyRegistered ? (
            <div className="w-full py-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Already Registered</span>
            </div>
          ) : isPastDeadline || isFull ? (
            <button
              disabled
              className="w-full py-2.5 rounded-xl bg-neutral-900 text-neutral-500 text-xs font-bold uppercase tracking-wider cursor-not-allowed border border-neutral-800"
            >
              {isPastDeadline ? 'Registration Closed' : 'Event Full'}
            </button>
          ) : (
            <button
              onClick={() => onRegister(event)}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] hover:from-[#6D28D9] hover:to-[#A21CAF] text-white font-extrabold text-xs uppercase tracking-wider shadow-lg shadow-violet-900/50 border border-violet-400/40 hover:border-[#F4D06F] group-hover:scale-[1.01] transition-all flex items-center justify-center gap-2"
            >
              <span>Register Now</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#F4D06F] group-hover:translate-x-1 transition-transform" />
            </button>
          )}
        </div>

      </div>

    </div>
  );
};
