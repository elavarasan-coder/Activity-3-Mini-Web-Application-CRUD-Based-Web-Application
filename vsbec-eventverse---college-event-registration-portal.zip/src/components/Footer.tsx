import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, Shield, Heart, MapPin, Phone, 
  Mail, ExternalLink, Calendar, Award 
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { adminProfile, setCurrentView, theme } = useApp();
  const isDark = theme === 'dark';

  return (
    <footer className={`no-print mt-auto border-t transition-colors duration-300 ${
      isDark 
        ? 'border-violet-500/20 bg-gradient-to-b from-[#0B1026] via-[#21113D] to-[#0B1026] text-neutral-300' 
        : 'border-violet-200 bg-gradient-to-b from-violet-50 via-white to-violet-50 text-neutral-700'
    }`}>
      
      {/* Top Aurora Luxe Gradient Accent Strip */}
      <div className="h-1 w-full bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#F4D06F]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Col 1: College & VSBEC EVENTVERSE Branding */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#7C3AED] via-[#C026D3] to-[#F4D06F] p-0.5 shadow-lg shadow-violet-900/40 flex items-center justify-center font-black text-[#F4D06F] text-xs">
                <div className="w-full h-full bg-[#0B1026] rounded-[10px] flex items-center justify-center">
                  VSB
                </div>
              </div>
              <div>
                <h3 className="text-sm font-extrabold uppercase font-heading leading-tight tracking-wider bg-gradient-to-r from-violet-400 via-fuchsia-400 to-[#F4D06F] bg-clip-text text-transparent">
                  VSBEC EVENTVERSE
                </h3>
                <span className="text-[10px] text-violet-400 font-bold uppercase tracking-widest block">
                  V.S.B. Engineering College, Karur
                </span>
              </div>
            </div>

            <p className="text-xs font-bold uppercase tracking-wider text-fuchsia-400 pt-1">
              COLLEGE EVENT REGISTRATION PORTAL
            </p>

            <p className="text-xs italic text-[#F4D06F] font-semibold">
              Connect • Create • Participate • Celebrate
            </p>

            <p className="text-[11px] text-neutral-400 leading-relaxed">
              Premium university event platform engineered for technical symposiums, 24-hr national hackathons, cultural festivals, workshops, sports championships, and research conclaves.
            </p>
          </div>

          {/* Col 2: Project Developer & Admin Details */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#F4D06F]" />
              <h4 className="text-xs font-extrabold uppercase tracking-wider font-heading text-violet-300">
                Admin & Developer Profile
              </h4>
            </div>

            <div className={`p-4 rounded-2xl border space-y-1.5 text-xs shadow-md ${
              isDark 
                ? 'bg-[#21113D]/60 border-violet-500/30' 
                : 'bg-white border-violet-200'
            }`}>
              <div className="font-extrabold text-sm text-white">
                {adminProfile.name}
              </div>
              <div className="text-[#F4D06F] font-mono-num font-bold text-[11px]">
                Register No: {adminProfile.registerNumber}
              </div>
              <div className="text-violet-300 text-[11px] font-medium">
                {adminProfile.classYear} • Dept of {adminProfile.department}
              </div>
              <div className="text-neutral-400 text-[11px] flex items-center gap-1.5 pt-1 font-mono-num">
                <Phone className="w-3.5 h-3.5 text-fuchsia-400" />
                <span>+91 {adminProfile.phone}</span>
              </div>
              <div className="text-neutral-400 text-[11px] flex items-center gap-1.5 truncate">
                <Mail className="w-3.5 h-3.5 text-[#F4D06F]" />
                <span>{adminProfile.email}</span>
              </div>
            </div>
          </div>

          {/* Col 3: Quick Navigation */}
          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider font-heading text-violet-300">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => setCurrentView('home')}
                  className="hover:text-fuchsia-400 transition-colors"
                >
                  Home & Flagship Events
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('events')}
                  className="hover:text-fuchsia-400 transition-colors"
                >
                  Explore All Events
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('digital-pass')}
                  className="hover:text-[#F4D06F] transition-colors"
                >
                  Generate Digital Event Pass
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="hover:text-violet-400 transition-colors"
                >
                  Admin Analytics Dashboard
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('docs')}
                  className="text-[#F4D06F] font-semibold hover:underline"
                >
                  Django Code & MySQL Schema (Viva)
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Campus Information */}
          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider font-heading text-violet-300">
              Campus Location
            </h4>
            <div className="space-y-2 text-xs text-neutral-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-fuchsia-400 shrink-0 mt-0.5" />
                <span>
                  NH-67, Covai Road, Karudayampalayam Post, Karur, Tamil Nadu - 639111
                </span>
              </div>
              <p className="text-[11px] leading-relaxed">
                Autonomous Institution Affiliated to Anna University, Chennai. Accredited with 'A' Grade by NAAC. Approved by AICTE, New Delhi.
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Strip */}
        <div className={`mt-10 pt-6 border-t flex flex-col sm:flex-row items-center justify-between text-xs gap-3 ${
          isDark ? 'border-violet-500/20 text-neutral-400' : 'border-violet-200 text-neutral-600'
        }`}>
          <div>
            © 2026 <strong>V.S.B. Engineering College, Karur</strong>. All Rights Reserved.
          </div>

          <div className="flex items-center gap-1.5 text-[11px]">
            <span>Developed by</span>
            <strong className="text-[#F4D06F]">ELAVARASAN R</strong>
            <span>(2nd Year ECE | Reg No: 922525106091)</span>
          </div>
        </div>

      </div>

    </footer>
  );
};
