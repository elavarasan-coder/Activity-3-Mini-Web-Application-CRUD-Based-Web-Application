import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Bell, Menu, X, Shield, GraduationCap, LogOut, 
  Calendar, CheckCircle, AlertCircle, Sparkles, User, Code2,
  Sun, Moon, Compass, Ticket, LayoutDashboard
} from 'lucide-react';

interface NavbarProps {
  onToggleSidebar: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar }) => {
  const { 
    auth, 
    notifications, 
    markNotificationAsRead, 
    markAllNotificationsAsRead, 
    logout, 
    setCurrentView,
    currentView,
    theme,
    toggleTheme
  } = useApp();

  const [showNotifications, setShowNotifications] = useState(false);
  const unreadCount = notifications.filter(n => !n.read).length;

  const isDark = theme === 'dark';

  return (
    <header className={`sticky top-0 z-40 transition-colors duration-300 backdrop-blur-xl border-b ${
      isDark 
        ? 'bg-[#0B1026]/90 border-violet-500/20 shadow-2xl shadow-purple-950/40 text-[#FFFDF7]' 
        : 'bg-[#FFFDF7]/90 border-violet-200/80 shadow-md shadow-violet-900/5 text-[#0B1026]'
    }`}>
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          
          {/* Left: Sidebar Toggle & VSBEC EVENTVERSE Branding */}
          <div className="flex items-center gap-3">
            <button
              onClick={onToggleSidebar}
              className={`p-2 rounded-xl border transition-all duration-200 ${
                isDark 
                  ? 'text-[#FFFDF7] bg-[#21113D]/60 border-violet-500/30 hover:bg-violet-600/30 hover:border-violet-400' 
                  : 'text-[#0B1026] bg-violet-50 border-violet-200 hover:bg-violet-100'
              }`}
              aria-label="Toggle Navigation Menu"
            >
              <Menu className="w-5 h-5 text-violet-400" />
            </button>

            <div 
              onClick={() => setCurrentView('home')}
              className="cursor-pointer flex items-center gap-3 group select-none"
            >
              {/* College Logo / Monogram */}
              <div className="relative">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#7C3AED] via-[#C026D3] to-[#F4D06F] p-[1.5px] shadow-lg shadow-violet-600/30 group-hover:shadow-violet-500/50 transition-all">
                  <div className="w-full h-full bg-[#0B1026] rounded-[10px] flex items-center justify-center font-black text-xs text-[#F4D06F] tracking-widest">
                    VSB
                  </div>
                </div>
                <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-fuchsia-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-[#C026D3]"></span>
                </span>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base sm:text-lg font-black tracking-tight font-heading bg-gradient-to-r from-[#FFFDF7] via-violet-200 to-[#F4D06F] bg-clip-text text-transparent">
                    VSBEC EVENTVERSE
                  </h1>
                  <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-violet-950/80 text-violet-300 border border-violet-500/30 tracking-wider uppercase">
                    Aurora Luxe
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="font-semibold text-violet-400 uppercase tracking-wider text-[10px]">
                    V.S.B. ENGINEERING COLLEGE, KARUR
                  </span>
                  <span className="hidden lg:inline text-neutral-500">•</span>
                  <span className="hidden lg:inline text-[10px] text-[#F4D06F] font-medium tracking-wide">
                    Connect • Create • Participate • Celebrate
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Center Quick Navigation (Desktop) */}
          <nav className="hidden xl:flex items-center gap-1.5 p-1 rounded-2xl bg-[#21113D]/40 border border-violet-500/20 backdrop-blur-md">
            <button
              onClick={() => setCurrentView('home')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                currentView === 'home'
                  ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-md shadow-purple-900/40'
                  : 'text-neutral-300 hover:text-white hover:bg-white/5'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => setCurrentView('events')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                currentView === 'events'
                  ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-md shadow-purple-900/40'
                  : 'text-neutral-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-violet-300" />
              <span>Events</span>
            </button>
            <button
              onClick={() => setCurrentView('digital-pass')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                currentView === 'digital-pass'
                  ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-md shadow-purple-900/40'
                  : 'text-neutral-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Ticket className="w-3.5 h-3.5 text-[#F4D06F]" />
              <span>Event Pass</span>
            </button>
            {auth.role === 'admin' ? (
              <button
                onClick={() => setCurrentView('dashboard')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  currentView === 'dashboard'
                    ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-md shadow-purple-900/40'
                    : 'text-neutral-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5 text-fuchsia-400" />
                <span>Dashboard</span>
              </button>
            ) : (
              <button
                onClick={() => setCurrentView('my-events')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  currentView === 'my-events'
                    ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-md shadow-purple-900/40'
                    : 'text-neutral-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <span>My Events</span>
              </button>
            )}
            <button
              onClick={() => setCurrentView('docs')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                currentView === 'docs'
                  ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-md shadow-purple-900/40'
                  : 'text-neutral-300 hover:text-[#F4D06F] hover:bg-white/5'
              }`}
            >
              <Code2 className="w-3.5 h-3.5 text-[#F4D06F]" />
              <span>Django & MySQL Docs</span>
            </button>
          </nav>

          {/* Right Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Theme Toggle (Aurora Dark / Ivory Light) */}
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-xl border transition-all duration-300 ${
                isDark 
                  ? 'bg-[#21113D]/60 border-violet-500/30 text-[#F4D06F] hover:bg-violet-600/20' 
                  : 'bg-violet-50 border-violet-200 text-violet-700 hover:bg-violet-100'
              }`}
              title={`Switch to ${isDark ? 'Ivory Light' : 'Aurora Dark'} mode`}
              aria-label="Toggle Theme"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Notification Bell */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className={`relative p-2 rounded-xl border transition-all ${
                  isDark 
                    ? 'bg-[#21113D]/60 border-violet-500/30 text-violet-300 hover:border-violet-400' 
                    : 'bg-violet-50 border-violet-200 text-violet-700 hover:border-violet-300'
                }`}
                aria-label="View notifications"
              >
                <Bell className="w-4 h-4 text-violet-400" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-gradient-to-r from-fuchsia-600 to-violet-600 text-[10px] font-black text-white shadow-lg animate-pulse ring-2 ring-[#0B1026]">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Notification Popup Dropdown */}
              {showNotifications && (
                <div className={`absolute right-0 mt-3 w-80 sm:w-96 rounded-3xl border shadow-2xl backdrop-blur-2xl z-50 overflow-hidden ${
                  isDark 
                    ? 'bg-[#0B1026]/95 border-violet-500/30 text-[#FFFDF7] shadow-purple-950/80' 
                    : 'bg-white/95 border-violet-200 text-[#0B1026] shadow-xl'
                }`}>
                  <div className="px-4 py-3.5 bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] border-b border-violet-500/20 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#F4D06F]" />
                      <h4 className="text-sm font-extrabold text-white tracking-wide">Notifications</h4>
                      <span className="text-[10px] bg-violet-600/40 text-violet-200 px-2 py-0.5 rounded-full border border-violet-500/30 font-bold">
                        {unreadCount} new
                      </span>
                    </div>
                    {unreadCount > 0 && (
                      <button
                        onClick={markAllNotificationsAsRead}
                        className="text-[11px] text-[#F4D06F] hover:underline font-semibold"
                      >
                        Mark all read
                      </button>
                    )}
                  </div>

                  <div className="max-h-80 overflow-y-auto divide-y divide-violet-500/10">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-xs text-neutral-400">
                        No notifications right now.
                      </div>
                    ) : (
                      notifications.slice(0, 5).map(notif => (
                        <div 
                          key={notif.id}
                          onClick={() => {
                            markNotificationAsRead(notif.id);
                            setShowNotifications(false);
                            setCurrentView('notifications');
                          }}
                          className={`p-3.5 transition-colors cursor-pointer hover:bg-violet-950/20 flex gap-3 items-start ${
                            !notif.read ? 'bg-violet-900/15' : ''
                          }`}
                        >
                          <div className={`mt-0.5 p-1.5 rounded-xl shrink-0 ${
                            notif.type === 'approval' || notif.type === 'success' 
                              ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/40'
                              : notif.type === 'deadline' 
                              ? 'bg-amber-950/70 text-[#F4D06F] border border-amber-800/40'
                              : notif.type === 'rejection'
                              ? 'bg-rose-950/70 text-rose-400 border border-rose-800/40'
                              : 'bg-violet-950/70 text-violet-300 border border-violet-800/40'
                          }`}>
                            {notif.type === 'approval' || notif.type === 'success' ? (
                              <CheckCircle className="w-3.5 h-3.5" />
                            ) : notif.type === 'deadline' ? (
                              <Calendar className="w-3.5 h-3.5" />
                            ) : (
                              <AlertCircle className="w-3.5 h-3.5" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-1">
                              <p className="text-xs font-bold text-white truncate">{notif.title}</p>
                              <span className="text-[10px] text-neutral-400 whitespace-nowrap font-mono-num">{notif.date}</span>
                            </div>
                            <p className="text-[11px] text-neutral-300 mt-0.5 line-clamp-2">{notif.message}</p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  <div className="p-2.5 bg-[#0B1026]/90 border-t border-violet-500/20 text-center">
                    <button
                      onClick={() => {
                        setShowNotifications(false);
                        setCurrentView('notifications');
                      }}
                      className="text-xs font-bold text-[#F4D06F] hover:text-amber-300"
                    >
                      View All Notifications →
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Auth User Badge */}
            {auth.isAuthenticated ? (
              <div className="flex items-center gap-1.5">
                <div 
                  onClick={() => setCurrentView(auth.role === 'admin' ? 'profile' : 'profile')}
                  className={`flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-2xl border cursor-pointer transition-all ${
                    isDark
                      ? 'bg-[#21113D]/60 border-violet-500/30 hover:border-violet-400'
                      : 'bg-violet-50 border-violet-200 hover:border-violet-300'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shadow-md ${
                    auth.role === 'admin'
                      ? 'bg-gradient-to-br from-[#7C3AED] via-[#C026D3] to-[#F4D06F] text-white'
                      : 'bg-gradient-to-br from-violet-700 to-indigo-900 text-white'
                  }`}>
                    {auth.role === 'admin' ? <Shield className="w-4 h-4 text-[#FFFDF7]" /> : <GraduationCap className="w-4 h-4 text-[#FFFDF7]" />}
                  </div>
                  <div className="hidden md:block text-left">
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span className="truncate max-w-[110px]">{auth.user?.name}</span>
                      {auth.role === 'admin' && (
                        <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded-full bg-[#C026D3]/30 text-fuchsia-300 border border-fuchsia-500/30">
                          Admin
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-violet-300/80 font-mono-num">
                      {auth.user?.registerNumber}
                    </div>
                  </div>
                </div>

                <button
                  onClick={logout}
                  className={`p-2 rounded-xl border transition-colors ${
                    isDark 
                      ? 'border-violet-500/20 text-neutral-400 hover:text-rose-400 hover:bg-rose-950/30' 
                      : 'border-violet-200 text-neutral-500 hover:text-rose-600 hover:bg-rose-50'
                  }`}
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setCurrentView('login')}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] hover:opacity-90 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-violet-900/40 border border-violet-400/40 transition-all flex items-center gap-1.5"
              >
                <User className="w-4 h-4" />
                <span>Sign In</span>
              </button>
            )}

          </div>

        </div>
      </div>
    </header>
  );
};
