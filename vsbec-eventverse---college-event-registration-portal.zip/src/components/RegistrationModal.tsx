import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { EventItem, Registration } from '../types';
import { 
  X, Sparkles, CheckCircle2, AlertCircle, Calendar, 
  MapPin, Clock, Users, ShieldCheck, Ticket, User, Mail, Phone, Building2 
} from 'lucide-react';

interface RegistrationModalProps {
  event: EventItem | null;
  onClose: () => void;
  onSuccess: (reg: Registration) => void;
}

export const RegistrationModal: React.FC<RegistrationModalProps> = ({ event, onClose, onSuccess }) => {
  const { auth, registerForEvent, setSelectedPassRegistration, setCurrentView } = useApp();

  const [studentName, setStudentName] = useState(auth.user?.name || '');
  const [registerNumber, setRegisterNumber] = useState(auth.user?.registerNumber || '');
  const [department, setDepartment] = useState(auth.user?.department || 'ECE');
  const [year, setYear] = useState(auth.user?.year || '2nd Year');
  const [phone, setPhone] = useState(auth.user?.phone || '7397112875');
  const [email, setEmail] = useState(auth.user?.email || 'student@vsbec.ac.in');
  
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successReg, setSuccessReg] = useState<Registration | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (auth.user) {
      if (auth.user.name) setStudentName(auth.user.name);
      if (auth.user.registerNumber) setRegisterNumber(auth.user.registerNumber);
      if (auth.user.department) setDepartment(auth.user.department);
      if (auth.user.year) setYear(auth.user.year);
      if (auth.user.phone) setPhone(auth.user.phone);
      if (auth.user.email) setEmail(auth.user.email);
    }
  }, [auth.user]);

  if (!event) return null;

  const today = new Date().toISOString().split('T')[0];
  const isPastDeadline = event.registrationDeadline < today;
  const isFull = event.currentParticipants >= event.maxParticipants;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Basic Validation
    if (!studentName.trim() || !registerNumber.trim() || !phone.trim() || !email.trim()) {
      setErrorMsg('Please fill in all required fields marked with *');
      return;
    }

    if (registerNumber.length < 6) {
      setErrorMsg('Register Number must be at least 6 alphanumeric characters.');
      return;
    }

    if (!/^\d{10}$/.test(phone.replace(/\D/g, ''))) {
      setErrorMsg('Please enter a valid 10-digit phone number.');
      return;
    }

    if (!email.includes('@') || !email.includes('.')) {
      setErrorMsg('Please enter a valid college email address.');
      return;
    }

    setIsSubmitting(true);

    const result = registerForEvent({
      studentName,
      registerNumber,
      department,
      year,
      phone,
      email,
      eventId: event.id
    });

    setIsSubmitting(false);

    if (result.success && result.registration) {
      setSuccessReg(result.registration);
      onSuccess(result.registration);
    } else {
      setErrorMsg(result.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl bg-[#0B1026] border-2 border-violet-500/40 rounded-3xl shadow-2xl shadow-purple-950/80 overflow-hidden my-8">
        
        {/* Modal Header */}
        <div className="relative bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] px-6 py-5 border-b border-violet-500/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-violet-600/30 border border-violet-400/60 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-[#F4D06F]" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white tracking-wide font-heading">
                  Event Registration Form
                </h3>
                <p className="text-[11px] text-[#F4D06F] font-bold">
                  V.S.B. Engineering College, Karur • VSBEC EVENTVERSE
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-neutral-400 hover:text-white hover:bg-white/[0.08] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Success View */}
        {successReg ? (
          <div className="p-6 sm:p-8 text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-emerald-950/90 border-2 border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto shadow-xl shadow-emerald-950/60 animate-bounce">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <span className="text-xs font-bold text-[#F4D06F] uppercase tracking-widest">
                Confirmation Notice
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-white mt-1 font-heading">
                REGISTRATION CONFIRMED!
              </h3>
              <p className="text-xs text-neutral-300 mt-2 max-w-md mx-auto">
                Congratulations <strong className="text-white">{successReg.studentName}</strong>! You have been successfully registered for <strong className="text-[#F4D06F]">{event.name}</strong>.
              </p>
            </div>

            <div className="bg-[#21113D]/40 p-5 rounded-3xl border border-violet-500/30 max-w-md mx-auto text-left space-y-2.5 shadow-inner">
              <div className="flex justify-between items-center text-xs">
                <span className="text-violet-300 font-medium">Generated Registration ID:</span>
                <span className="font-mono-num font-extrabold text-[#F4D06F] bg-violet-950/80 px-2.5 py-0.5 rounded-full border border-violet-500/40">
                  {successReg.registrationId}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-neutral-400">Student Register No:</span>
                <span className="font-mono-num text-white font-bold">{successReg.registerNumber}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-neutral-400">Department & Year:</span>
                <span className="text-neutral-200">{successReg.department} ({successReg.year})</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-neutral-400">Scheduled Date:</span>
                <span className="text-[#F4D06F] font-semibold">{successReg.eventDate}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-neutral-400">Status:</span>
                <span className="text-emerald-400 font-bold uppercase">{successReg.status}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
              <button
                onClick={() => {
                  setSelectedPassRegistration(successReg);
                  setCurrentView('digital-pass');
                  onClose();
                }}
                className="flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] text-white font-extrabold text-xs uppercase tracking-wider shadow-xl shadow-violet-900/60 border border-violet-400/50 hover:scale-105 transition-all"
              >
                <Ticket className="w-4 h-4 text-[#F4D06F]" />
                <span>View Digital Event Pass</span>
              </button>

              <button
                onClick={onClose}
                className="px-5 py-3 rounded-2xl bg-[#21113D]/60 hover:bg-[#21113D] text-neutral-300 font-bold text-xs uppercase tracking-wider border border-violet-500/30 transition-colors"
              >
                Done / Close
              </button>
            </div>
          </div>
        ) : (
          /* Registration Form */
          <form onSubmit={handleSubmit} className="p-6 space-y-5">
            
            {/* Event Summary Card */}
            <div className="p-4 rounded-2xl bg-[#21113D]/40 border border-violet-500/30">
              <div className="flex items-center justify-between text-[11px] font-bold text-[#F4D06F] uppercase tracking-wider mb-1">
                <span>{event.category} Event</span>
                <span className="font-mono-num text-violet-300">{event.eventId}</span>
              </div>
              <h4 className="text-sm sm:text-base font-extrabold text-white">
                {event.name}
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-3 pt-3 border-t border-violet-500/20 text-xs text-neutral-300">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-fuchsia-400" />
                  <span className="truncate">{event.date}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#F4D06F]" />
                  <span className="truncate">{event.venue}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-violet-400" />
                  <span>{event.currentParticipants}/{event.maxParticipants}</span>
                </div>
              </div>
            </div>

            {/* Error or Warning Banner */}
            {isPastDeadline && (
              <div className="p-3.5 rounded-2xl bg-rose-950/60 border border-rose-700/60 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>Registration deadline ({event.registrationDeadline}) has passed for this event.</span>
              </div>
            )}

            {isFull && (
              <div className="p-3.5 rounded-2xl bg-amber-950/60 border border-amber-700/60 text-amber-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Maximum participant limit ({event.maxParticipants}) has been reached.</span>
              </div>
            )}

            {errorMsg && (
              <div className="p-3.5 rounded-2xl bg-rose-950/80 border border-rose-600 text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Fields */}
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Student Full Name *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-violet-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      required
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      placeholder="e.g. Karthik Raja S"
                      className="w-full bg-[#21113D]/40 text-white text-xs rounded-xl pl-9 pr-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Register Number *
                  </label>
                  <div className="relative">
                    <span className="text-violet-400 font-bold text-xs absolute left-3 top-2.5">#</span>
                    <input
                      type="text"
                      required
                      value={registerNumber}
                      onChange={(e) => setRegisterNumber(e.target.value)}
                      placeholder="e.g. 922525106012"
                      className="w-full bg-[#21113D]/40 text-white text-xs font-mono-num rounded-xl pl-8 pr-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Department *
                  </label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full bg-[#21113D]/60 text-white text-xs rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  >
                    <option value="ECE">ECE (Electronics & Communication)</option>
                    <option value="CSE">CSE (Computer Science & Engg)</option>
                    <option value="IT">IT (Information Technology)</option>
                    <option value="AIDS">AIDS (AI & Data Science)</option>
                    <option value="EEE">EEE (Electrical & Electronics)</option>
                    <option value="MECH">MECH (Mechanical Engineering)</option>
                    <option value="CIVIL">CIVIL (Civil Engineering)</option>
                    <option value="BIOMEDICAL">Biomedical Engineering</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Class / Year *
                  </label>
                  <select
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    className="w-full bg-[#21113D]/60 text-white text-xs rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  >
                    <option value="1st Year">1st Year</option>
                    <option value="2nd Year">2nd Year</option>
                    <option value="3rd Year">3rd Year</option>
                    <option value="4th Year">4th Year</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Phone Number *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-violet-400 absolute left-3 top-3" />
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="10-digit mobile number"
                      className="w-full bg-[#21113D]/40 text-white text-xs rounded-xl pl-9 pr-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-mono-num"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    College Email *
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-violet-400 absolute left-3 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. karthik.ece@vsbec.ac.in"
                      className="w-full bg-[#21113D]/40 text-white text-xs rounded-xl pl-9 pr-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Readonly info */}
              <div className="p-3.5 bg-[#21113D]/30 rounded-2xl border border-violet-500/20 text-[11px] text-neutral-400 space-y-1">
                <div className="flex justify-between">
                  <span>Target Event:</span>
                  <span className="text-white font-semibold">{event.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Scheduled Date:</span>
                  <span className="text-[#F4D06F]">{event.date} ({event.startTime})</span>
                </div>
                <div className="flex justify-between">
                  <span>Registration Date:</span>
                  <span className="text-violet-300 font-mono-num">{new Date().toLocaleDateString('en-US')} (Auto-logged)</span>
                </div>
              </div>
            </div>

            {/* Submit Action */}
            <div className="pt-2 flex items-center justify-end gap-3 border-t border-violet-500/20">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-neutral-400 hover:text-white text-xs font-semibold transition-colors"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={isPastDeadline || isFull || isSubmitting}
                className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-violet-950 border border-violet-400/50 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-[#F4D06F]" />
                <span>{isSubmitting ? 'Verifying...' : 'Confirm & Register Now'}</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
