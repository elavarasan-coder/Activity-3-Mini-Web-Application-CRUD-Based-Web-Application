import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Home, Calendar, ClipboardList, Ticket, Bell, 
  User, LogOut, LayoutDashboard, Users, Settings, 
  Code2, Sparkles, ChevronRight, BarChart3, Compass, Shield
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const { auth, currentView, setCurrentView, logout, adminProfile, notifications, theme } = useApp();

  const unreadCount = notifications.filter(n => !n.read).length;
  const isDark = theme === 'dark';

  const handleNavClick = (view: string) => {
    setCurrentView(view);
    if (window.innerWidth < 1024) {
      onClose();
    }
  };

  // Student Navigation per prompt
  const studentNav = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'events', label: 'Explore Events', icon: Compass },
    { id: 'my-events', label: 'My Registrations', icon: ClipboardList },
    { id: 'digital-pass', label: 'Event Pass', icon: Ticket },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadCount },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'docs', label: 'Project Docs & Viva', icon: Code2, highlight: true },
  ];

  // Admin Navigation per prompt
  const adminNav = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'events-manage', label: 'Events Management', icon: Calendar },
    { id: 'students-manage', label: 'Students Directory', icon: Users },
    { id: 'registrations-manage', label: 'Registrations Review', icon: ClipboardList },
    { id: 'digital-pass', label: 'Verify Event Pass', icon: Ticket },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadCount },
    { id: 'profile', label: 'Admin Profile', icon: User },
    { id: 'docs', label: 'Django & MySQL Code', icon: Code2, highlight: true },
  ];

  const navItems = auth.role === 'admin' ? adminNav : studentNav;

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          onClick={onClose}
          className="fixed inset-0 bg-[#0B1026]/80 backdrop-blur-md z-40 lg:hidden transition-opacity"
        />
      )}

      {/* Sidebar Drawer */}
      <aside className={`fixed top-18 bottom-0 left-0 z-40 w-72 backdrop-blur-2xl border-r transition-all duration-300 ease-in-out lg:translate-x-0 flex flex-col justify-between ${
        isDark 
          ? 'bg-[#0B1026]/95 border-violet-500/20 shadow-2xl shadow-purple-950/50 text-[#FFFDF7]' 
          : 'bg-[#FFFDF7]/98 border-violet-200 shadow-xl text-[#0B1026]'
      } ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        
        {/* Navigation list */}
        <div className="p-4 space-y-5 overflow-y-auto flex-1 scrollbar-thin">
          
          {/* Role Status Card */}
          <div className={`p-3.5 rounded-2xl border shadow-lg transition-all ${
            isDark 
              ? 'bg-gradient-to-br from-[#21113D] via-[#0B1026] to-[#21113D] border-violet-500/30' 
              : 'bg-gradient-to-br from-violet-50 to-fuchsia-50 border-violet-200'
          }`}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-violet-400 uppercase tracking-widest">
                Active Portal
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-widest border ${
                auth.role === 'admin' 
                  ? 'bg-fuchsia-950/80 text-[#F4D06F] border-fuchsia-500/50' 
                  : 'bg-violet-950/80 text-violet-300 border-violet-500/40'
              }`}>
                {auth.role === 'admin' ? '🛡️ Administrator' : '🎓 Student'}
              </span>
            </div>

            <div className="mt-2 text-xs font-black truncate">
              {auth.user?.name || 'Guest User'}
            </div>
            <div className="text-[11px] text-violet-300 font-mono-num">
              {auth.user?.registerNumber} {auth.user?.department ? `• ${auth.user.department}` : ''}
            </div>
          </div>

          {/* Nav Items */}
          <nav className="space-y-1">
            <div className="px-3 pb-2 text-[10px] font-extrabold text-violet-400/80 uppercase tracking-widest">
              {auth.role === 'admin' ? 'Administration Suite' : 'Student Event Hub'}
            </div>

            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-semibold transition-all group relative overflow-hidden ${
                    isActive
                      ? 'bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] text-white shadow-lg shadow-violet-900/50 border border-violet-400/40'
                      : item.highlight
                      ? isDark 
                        ? 'text-[#F4D06F] hover:bg-violet-950/40 border border-[#F4D06F]/20 hover:border-[#F4D06F]/50'
                        : 'text-violet-900 hover:bg-violet-100/60 border border-violet-300'
                      : isDark
                      ? 'text-neutral-300 hover:text-white hover:bg-white/[0.05]'
                      : 'text-neutral-700 hover:text-violet-950 hover:bg-violet-100/50'
                  }`}
                >
                  <div className="flex items-center gap-3 relative z-10">
                    <Icon className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                      isActive 
                        ? 'text-[#FFFDF7]' 
                        : item.highlight 
                        ? 'text-[#F4D06F]' 
                        : 'text-violet-400 group-hover:text-fuchsia-400'
                    }`} />
                    <span className="tracking-wide font-medium">{item.label}</span>
                  </div>

                  <div className="relative z-10 flex items-center gap-1.5">
                    {item.badge !== undefined && item.badge > 0 ? (
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-gradient-to-r from-fuchsia-600 to-violet-600 text-white shadow-md">
                        {item.badge}
                      </span>
                    ) : isActive ? (
                      <ChevronRight className="w-4 h-4 text-[#FFFDF7]" />
                    ) : null}
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer Admin Info & Logout */}
        <div className={`p-4 border-t ${
          isDark ? 'border-violet-500/20 bg-[#0B1026]/90' : 'border-violet-200 bg-violet-50/50'
        }`}>
          <div className={`p-3 rounded-2xl border mb-3 shadow-inner ${
            isDark 
              ? 'bg-[#21113D]/60 border-violet-500/30' 
              : 'bg-white border-violet-200'
          }`}>
            <div className="flex items-center justify-between text-[10px] text-[#F4D06F] font-bold uppercase tracking-wider">
              <span>Admin Profile</span>
              <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
            </div>
            <div className="text-xs font-black mt-1">
              {adminProfile.name}
            </div>
            <div className="text-[11px] text-violet-400 font-mono-num font-semibold">
              Reg No: {adminProfile.registerNumber}
            </div>
            <div className="text-[10px] text-neutral-400">
              {adminProfile.classYear} • {adminProfile.department} Dept
            </div>
          </div>

          <button
            onClick={logout}
            className={`w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold transition-all border ${
              isDark 
                ? 'border-violet-500/20 text-neutral-400 hover:text-rose-400 hover:bg-rose-950/30' 
                : 'border-violet-200 text-neutral-600 hover:text-rose-600 hover:bg-rose-50'
            }`}
          >
            <LogOut className="w-4 h-4 text-rose-500" />
            <span>Sign Out Session</span>
          </button>
        </div>

      </aside>
    </>
  );
};
