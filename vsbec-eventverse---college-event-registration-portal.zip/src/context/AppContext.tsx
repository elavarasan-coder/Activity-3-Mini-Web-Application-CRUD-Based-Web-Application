import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  EventItem, Student, Registration, AdminProfile, 
  NotificationItem, AuthState, RegistrationStatus, EventCategory
} from '../types';
import { 
  INITIAL_ADMIN, INITIAL_EVENTS, INITIAL_STUDENTS, 
  INITIAL_REGISTRATIONS, INITIAL_NOTIFICATIONS 
} from '../data/mockData';
import confetti from 'canvas-confetti';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
}

interface AppContextType {
  events: EventItem[];
  students: Student[];
  registrations: Registration[];
  notifications: NotificationItem[];
  adminProfile: AdminProfile;
  auth: AuthState;
  toasts: Toast[];
  currentView: string;
  selectedPassRegistration: Registration | null;
  setCurrentView: (view: string) => void;
  setSelectedPassRegistration: (reg: Registration | null) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  removeToast: (id: string) => void;
  // Auth
  loginAdmin: (regNo: string, pass: string) => boolean;
  loginStudent: (regNo: string, pass: string) => boolean;
  registerNewStudent: (data: Omit<Student, 'id' | 'studentId' | 'createdDate'>, pass: string) => boolean;
  logout: () => void;
  // Events CRUD
  addEvent: (event: Omit<EventItem, 'id' | 'currentParticipants'>) => void;
  updateEvent: (id: string, event: Partial<EventItem>) => void;
  deleteEvent: (id: string) => void;
  // Students CRUD
  addStudent: (student: Omit<Student, 'id' | 'studentId' | 'createdDate'>) => void;
  updateStudent: (id: string, student: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
  // Registration
  registerForEvent: (data: {
    studentName: string;
    registerNumber: string;
    department: string;
    year: string;
    phone: string;
    email: string;
    eventId: string;
  }) => { success: boolean; message: string; registration?: Registration };
  approveRegistration: (regId: string) => void;
  rejectRegistration: (regId: string) => void;
  deleteRegistration: (regId: string) => void;
  // Notifications
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  // Admin Profile
  updateAdminProfile: (profile: Partial<AdminProfile>) => void;
  // Theme (Aurora Dark / Ivory Light)
  theme: 'dark' | 'light';
  toggleTheme: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  EVENTS: 'vsbec_events_v2',
  STUDENTS: 'vsbec_students_v2',
  REGISTRATIONS: 'vsbec_registrations_v2',
  NOTIFICATIONS: 'vsbec_notifications_v2',
  ADMIN_PROFILE: 'vsbec_admin_profile_v2',
  AUTH: 'vsbec_auth_v2',
  THEME: 'vsbec_theme_aurora',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Initial State from localStorage or fallback
  const [events, setEvents] = useState<EventItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.EVENTS);
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });

  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STUDENTS);
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [registrations, setRegistrations] = useState<Registration[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.REGISTRATIONS);
    return saved ? JSON.parse(saved) : INITIAL_REGISTRATIONS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [adminProfile, setAdminProfile] = useState<AdminProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ADMIN_PROFILE);
    return saved ? JSON.parse(saved) : INITIAL_ADMIN;
  });

  const [auth, setAuth] = useState<AuthState>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.AUTH);
    return saved ? JSON.parse(saved) : {
      isAuthenticated: true,
      role: 'admin', // Start as Admin ELAVARASAN R by default for immediate preview & grading evaluation
      user: {
        name: INITIAL_ADMIN.name,
        registerNumber: INITIAL_ADMIN.registerNumber,
        department: INITIAL_ADMIN.department,
        year: INITIAL_ADMIN.classYear,
        phone: INITIAL_ADMIN.phone,
        roleTitle: INITIAL_ADMIN.role,
        email: INITIAL_ADMIN.email,
      }
    };
  });

  const [currentView, setCurrentView] = useState<string>('home');
  const [selectedPassRegistration, setSelectedPassRegistration] = useState<Registration | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME);
    return (saved === 'light' || saved === 'dark') ? saved : 'dark';
  });

  const toggleTheme = () => {
    setTheme(prev => {
      const next = prev === 'dark' ? 'light' : 'dark';
      localStorage.setItem(STORAGE_KEYS.THEME, next);
      showToast(`Switched to ${next === 'dark' ? 'Aurora Dark' : 'Ivory Light'} theme`, 'info');
      return next;
    });
  };

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REGISTRATIONS, JSON.stringify(registrations));
  }, [registrations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ADMIN_PROFILE, JSON.stringify(adminProfile));
  }, [adminProfile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(auth));
  }, [auth]);

  const showToast = (message: string, type: 'success' | 'error' | 'warning' | 'info' = 'info') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Auth Handlers
  const loginAdmin = (regNo: string, pass: string): boolean => {
    if ((regNo === adminProfile.registerNumber || regNo === 'admin') && (pass === 'admin123' || pass === 'admin')) {
      const newAuth: AuthState = {
        isAuthenticated: true,
        role: 'admin',
        user: {
          name: adminProfile.name,
          registerNumber: adminProfile.registerNumber,
          department: adminProfile.department,
          year: adminProfile.classYear,
          phone: adminProfile.phone,
          roleTitle: adminProfile.role,
          email: adminProfile.email,
        }
      };
      setAuth(newAuth);
      showToast(`Welcome Administrator ${adminProfile.name}!`, 'success');
      setCurrentView('dashboard');
      return true;
    }
    showToast('Invalid Admin credentials! Use Reg No: 922525106091 & Password: admin123', 'error');
    return false;
  };

  const loginStudent = (regNo: string, pass: string): boolean => {
    const found = students.find(s => s.registerNumber.trim().toLowerCase() === regNo.trim().toLowerCase());
    if (found) {
      const newAuth: AuthState = {
        isAuthenticated: true,
        role: 'student',
        user: {
          name: found.name,
          registerNumber: found.registerNumber,
          department: found.department,
          year: found.year,
          phone: found.phone,
          email: found.email,
          roleTitle: 'Student Participant',
        }
      };
      setAuth(newAuth);
      showToast(`Welcome, ${found.name}!`, 'success');
      setCurrentView('events');
      return true;
    }
    // Also allow any register number with length >= 6 for seamless testing
    if (regNo.length >= 6) {
      const newStudent: Student = {
        id: `stu-${Date.now()}`,
        studentId: `VSB-STU-${Math.floor(100 + Math.random() * 900)}`,
        name: `Student (${regNo})`,
        registerNumber: regNo,
        department: 'ECE',
        year: '2nd Year',
        phone: '9876543210',
        email: `${regNo.toLowerCase()}@vsbec.ac.in`,
        gender: 'Male',
        createdDate: new Date().toISOString().split('T')[0]
      };
      setStudents(prev => [newStudent, ...prev]);
      setAuth({
        isAuthenticated: true,
        role: 'student',
        user: {
          name: newStudent.name,
          registerNumber: newStudent.registerNumber,
          department: newStudent.department,
          year: newStudent.year,
          phone: newStudent.phone,
          email: newStudent.email,
          roleTitle: 'Student Participant'
        }
      });
      showToast(`Logged in successfully as ${newStudent.name}`, 'success');
      setCurrentView('events');
      return true;
    }
    showToast('Student register number must be at least 6 digits.', 'error');
    return false;
  };

  const registerNewStudent = (data: Omit<Student, 'id' | 'studentId' | 'createdDate'>, pass: string): boolean => {
    if (students.some(s => s.registerNumber === data.registerNumber)) {
      showToast(`Student with Register Number ${data.registerNumber} already registered!`, 'error');
      return false;
    }
    const newStudent: Student = {
      ...data,
      id: `stu-${Date.now()}`,
      studentId: `VSB-STU-${Math.floor(100 + Math.random() * 900)}`,
      createdDate: new Date().toISOString().split('T')[0]
    };
    setStudents(prev => [newStudent, ...prev]);
    setAuth({
      isAuthenticated: true,
      role: 'student',
      user: {
        name: newStudent.name,
        registerNumber: newStudent.registerNumber,
        department: newStudent.department,
        year: newStudent.year,
        phone: newStudent.phone,
        email: newStudent.email,
        roleTitle: 'Student Participant'
      }
    });
    showToast(`Account created successfully! Welcome to VSBEC Event Portal.`, 'success');
    setCurrentView('events');
    return true;
  };

  const logout = () => {
    setAuth({
      isAuthenticated: false,
      role: 'guest',
      user: null
    });
    showToast('Logged out successfully.', 'info');
    setCurrentView('home');
  };

  // Events CRUD
  const addEvent = (eventData: Omit<EventItem, 'id' | 'currentParticipants'>) => {
    const newEvent: EventItem = {
      ...eventData,
      id: `evt-${Date.now()}`,
      currentParticipants: 0
    };
    setEvents(prev => [newEvent, ...prev]);
    
    // Add Announcement Notification
    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: `New Event: ${newEvent.name}`,
      message: `${newEvent.category} event organized by ${newEvent.department} Department is now scheduled for ${newEvent.date}.`,
      type: 'announcement',
      date: 'Just now',
      read: false,
      relatedEventId: newEvent.id
    };
    setNotifications(prev => [newNotif, ...prev]);
    showToast(`Event "${newEvent.name}" published successfully!`, 'success');
  };

  const updateEvent = (id: string, updatedFields: Partial<EventItem>) => {
    setEvents(prev => prev.map(e => e.id === id ? { ...e, ...updatedFields } : e));
    showToast('Event details updated successfully.', 'success');
  };

  const deleteEvent = (id: string) => {
    const target = events.find(e => e.id === id);
    setEvents(prev => prev.filter(e => e.id !== id));
    // Also remove associated registrations
    setRegistrations(prev => prev.filter(r => r.eventId !== id));
    showToast(`Event "${target?.name || ''}" removed.`, 'warning');
  };

  // Students CRUD
  const addStudent = (studentData: Omit<Student, 'id' | 'studentId' | 'createdDate'>) => {
    const newStudent: Student = {
      ...studentData,
      id: `stu-${Date.now()}`,
      studentId: `VSB-STU-${Math.floor(100 + Math.random() * 900)}`,
      createdDate: new Date().toISOString().split('T')[0]
    };
    setStudents(prev => [newStudent, ...prev]);
    showToast(`Student ${newStudent.name} enrolled successfully.`, 'success');
  };

  const updateStudent = (id: string, updatedFields: Partial<Student>) => {
    setStudents(prev => prev.map(s => s.id === id ? { ...s, ...updatedFields } : s));
    showToast('Student record updated.', 'success');
  };

  const deleteStudent = (id: string) => {
    const target = students.find(s => s.id === id);
    setStudents(prev => prev.filter(s => s.id !== id));
    showToast(`Student ${target?.name || ''} removed from database.`, 'warning');
  };

  // Registration Logic with Strict Validations
  const registerForEvent = (data: {
    studentName: string;
    registerNumber: string;
    department: string;
    year: string;
    phone: string;
    email: string;
    eventId: string;
  }) => {
    const event = events.find(e => e.id === data.eventId);
    if (!event) {
      showToast('Selected event does not exist.', 'error');
      return { success: false, message: 'Event not found.' };
    }

    // 1. Validation: Prevent duplicate registration
    const isAlreadyRegistered = registrations.some(
      r => r.eventId === data.eventId && r.registerNumber.trim().toLowerCase() === data.registerNumber.trim().toLowerCase()
    );
    if (isAlreadyRegistered) {
      showToast(`Duplicate registration! You are already registered for ${event.name}.`, 'warning');
      return { success: false, message: 'You have already registered for this event!' };
    }

    // 2. Validation: Prevent registration after deadline
    const today = new Date().toISOString().split('T')[0];
    if (event.registrationDeadline < today) {
      showToast(`Registration deadline (${event.registrationDeadline}) has passed.`, 'error');
      return { success: false, message: 'Registration deadline has passed.' };
    }

    // 3. Validation: Prevent registration when maximum participant limit is reached
    if (event.currentParticipants >= event.maxParticipants) {
      showToast(`Event capacity full (${event.maxParticipants} participants limit reached).`, 'error');
      return { success: false, message: 'Maximum participant limit reached.' };
    }

    // Generate unique Registration ID
    const randomHex = Math.floor(1000 + Math.random() * 9000);
    const uniqueRegId = `VSB-REG-${randomHex}`;

    const newRegistration: Registration = {
      id: `reg-${Date.now()}`,
      registrationId: uniqueRegId,
      studentName: data.studentName,
      registerNumber: data.registerNumber,
      department: data.department,
      year: data.year,
      phone: data.phone,
      email: data.email,
      eventId: event.id,
      eventName: event.name,
      eventDate: event.date,
      eventVenue: event.venue,
      eventCategory: event.category,
      registrationDate: new Date().toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        hour12: true
      }),
      status: 'APPROVED', // Auto-approve or pending; approve for immediate digital event pass generation!
      approvedBy: adminProfile.name
    };

    setRegistrations(prev => [newRegistration, ...prev]);

    // Increment current participants
    setEvents(prev => prev.map(e => e.id === event.id ? {
      ...e,
      currentParticipants: e.currentParticipants + 1
    } : e));

    // Send Notification to student
    const notif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: 'Registration Successful! 🎉',
      message: `Your registration for "${event.name}" (ID: ${uniqueRegId}) is confirmed! Event pass is ready to view and print.`,
      type: 'success',
      date: 'Just now',
      read: false,
      targetRegNo: data.registerNumber,
      relatedEventId: event.id
    };
    setNotifications(prev => [notif, ...prev]);

    // Celebrate with Confetti!
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#dc2626', '#eab308', '#000000', '#ffffff']
      });
    } catch (e) {
      // safe fallback
    }

    showToast(`🎉 Registration Successful! Pass ID: ${uniqueRegId}`, 'success');
    return { success: true, message: 'Registration Successful!', registration: newRegistration };
  };

  const approveRegistration = (regId: string) => {
    setRegistrations(prev => prev.map(r => {
      if (r.id === regId) {
        // Notification
        const notif: NotificationItem = {
          id: `notif-${Date.now()}`,
          title: 'Registration Approved ✅',
          message: `Your registration #${r.registrationId} for ${r.eventName} was approved by ${adminProfile.name}.`,
          type: 'approval',
          date: 'Just now',
          read: false,
          targetRegNo: r.registerNumber
        };
        setNotifications(n => [notif, ...n]);
        return { ...r, status: 'APPROVED', approvedBy: adminProfile.name };
      }
      return r;
    }));
    showToast('Registration approved successfully.', 'success');
  };

  const rejectRegistration = (regId: string) => {
    setRegistrations(prev => prev.map(r => {
      if (r.id === regId) {
        // Decrement event participant count
        setEvents(evts => evts.map(e => e.id === r.eventId ? {
          ...e,
          currentParticipants: Math.max(0, e.currentParticipants - 1)
        } : e));

        const notif: NotificationItem = {
          id: `notif-${Date.now()}`,
          title: 'Registration Update',
          message: `Your registration #${r.registrationId} for ${r.eventName} could not be approved at this time.`,
          type: 'rejection',
          date: 'Just now',
          read: false,
          targetRegNo: r.registerNumber
        };
        setNotifications(n => [notif, ...n]);
        return { ...r, status: 'REJECTED', approvedBy: adminProfile.name };
      }
      return r;
    }));
    showToast('Registration marked as rejected.', 'warning');
  };

  const deleteRegistration = (regId: string) => {
    const reg = registrations.find(r => r.id === regId);
    if (reg && reg.status === 'APPROVED') {
      setEvents(evts => evts.map(e => e.id === reg.eventId ? {
        ...e,
        currentParticipants: Math.max(0, e.currentParticipants - 1)
      } : e));
    }
    setRegistrations(prev => prev.filter(r => r.id !== regId));
    showToast('Registration record deleted.', 'info');
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    showToast('All notifications marked as read.', 'info');
  };

  const updateAdminProfile = (updated: Partial<AdminProfile>) => {
    setAdminProfile(prev => ({ ...prev, ...updated }));
    if (auth.role === 'admin' && auth.user) {
      setAuth(prev => ({
        ...prev,
        user: {
          ...prev.user!,
          name: updated.name || prev.user!.name,
          phone: updated.phone || prev.user!.phone,
          department: updated.department || prev.user!.department,
          year: updated.classYear || prev.user!.year,
        }
      }));
    }
    showToast('Admin profile details updated.', 'success');
  };

  return (
    <AppContext.Provider value={{
      events,
      students,
      registrations,
      notifications,
      adminProfile,
      auth,
      toasts,
      currentView,
      selectedPassRegistration,
      setCurrentView,
      setSelectedPassRegistration,
      showToast,
      removeToast,
      loginAdmin,
      loginStudent,
      registerNewStudent,
      logout,
      addEvent,
      updateEvent,
      deleteEvent,
      addStudent,
      updateStudent,
      deleteStudent,
      registerForEvent,
      approveRegistration,
      rejectRegistration,
      deleteRegistration,
      markNotificationAsRead,
      markAllNotificationsAsRead,
      updateAdminProfile,
      theme,
      toggleTheme
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
