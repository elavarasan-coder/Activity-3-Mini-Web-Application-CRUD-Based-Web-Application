export const DJANGO_MODELS_CODE = `# backend/events/models.py
from django.db import models
from django.contrib.auth.models import AbstractUser

class AdminProfile(models.Model):
    name = models.CharField(max_length=150, default="ELAVARASAN R")
    register_number = models.CharField(max_length=50, unique=True, default="922525106091")
    class_year = models.CharField(max_length=50, default="2nd Year")
    department = models.CharField(max_length=50, default="ECE")
    phone_number = models.CharField(max_length=15, default="7397112875")
    role = models.CharField(max_length=100, default="Event Administrator")
    college_name = models.CharField(max_length=200, default="V.S.B. Engineering College, Karur")
    email = models.EmailField(default="elavarasan.ece2nd@vsbec.ac.in")

    def __str__(self):
        return f"{self.name} ({self.register_number})"

class Student(models.Model):
    GENDER_CHOICES = (
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    )
    YEAR_CHOICES = (
        ('1st Year', '1st Year'),
        ('2nd Year', '2nd Year'),
        ('3rd Year', '3rd Year'),
        ('4th Year', '4th Year'),
    )

    student_id = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=150)
    register_number = models.CharField(max_length=20, unique=True)
    department = models.CharField(max_length=50)
    year = models.CharField(max_length=20, choices=YEAR_CHOICES)
    phone = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    password = models.CharField(max_length=128, default="student123")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.register_number} - {self.name}"

class Event(models.Model):
    CATEGORY_CHOICES = (
        ('Technical', 'Technical'),
        ('Cultural', 'Cultural'),
        ('Sports', 'Sports'),
        ('Workshop', 'Workshop'),
        ('Seminar', 'Seminar'),
        ('Hackathon', 'Hackathon'),
        ('Symposium', 'Symposium'),
        ('Club Event', 'Club Event'),
    )
    STATUS_CHOICES = (
        ('UPCOMING', 'UPCOMING'),
        ('ONGOING', 'ONGOING'),
        ('COMPLETED', 'COMPLETED'),
        ('CANCELLED', 'CANCELLED'),
    )

    event_id = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=200)
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    description = models.TextField()
    date = models.DateField()
    start_time = models.CharField(max_length=20)
    end_time = models.CharField(max_length=20)
    venue = models.CharField(max_length=200)
    organizer = models.CharField(max_length=150)
    department = models.CharField(max_length=100)
    max_participants = models.PositiveIntegerField(default=100)
    current_participants = models.PositiveIntegerField(default=0)
    registration_deadline = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='UPCOMING')
    image_url = models.URLField(max_length=500, blank=True, null=True)

    def __str__(self):
        return f"{self.event_id} - {self.name}"

class Registration(models.Model):
    STATUS_CHOICES = (
        ('PENDING', 'PENDING'),
        ('APPROVED', 'APPROVED'),
        ('REJECTED', 'REJECTED'),
    )

    registration_id = models.CharField(max_length=40, unique=True)
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='registrations')
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='registrations')
    registration_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    approved_by = models.CharField(max_length=150, blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)

    class Meta:
        unique_together = ('student', 'event')  # Prevent duplicate registration!

    def __str__(self):
        return f"{self.registration_id} - {self.student.name} ({self.event.name})"

class Notification(models.Model):
    TYPE_CHOICES = (
        ('announcement', 'Announcement'),
        ('success', 'Success'),
        ('approval', 'Approval'),
        ('rejection', 'Rejection'),
        ('deadline', 'Deadline'),
        ('reminder', 'Reminder'),
    )

    title = models.CharField(max_length=200)
    message = models.TextField()
    type = models.CharField(max_length=30, choices=TYPE_CHOICES, default='announcement')
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    target_student = models.ForeignKey(Student, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.title

class EventPass(models.Model):
    registration = models.OneToOneField(Registration, on_delete=models.CASCADE, related_name='event_pass')
    pass_number = models.CharField(max_length=50, unique=True)
    generated_at = models.DateTimeField(auto_now_add=True)
    qr_code_data = models.CharField(max_length=255)

    def __str__(self):
        return f"PASS: {self.pass_number}"
`;

export const DJANGO_SERIALIZERS_CODE = `# backend/events/serializers.py
from rest_framework import serializers
from .models import AdminProfile, Student, Event, Registration, Notification, EventPass

class AdminProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdminProfile
        fields = '__all__'

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ['id', 'student_id', 'name', 'register_number', 'department', 'year', 'phone', 'email', 'gender', 'created_at']

class EventSerializer(serializers.ModelSerializer):
    is_full = serializers.SerializerMethodField()

    class Meta:
        model = Event
        fields = '__all__'

    def get_is_full(self, obj):
        return obj.current_participants >= obj.max_participants

class RegistrationSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.name', read_only=True)
    register_number = serializers.CharField(source='student.register_number', read_only=True)
    student_department = serializers.CharField(source='student.department', read_only=True)
    student_year = serializers.CharField(source='student.year', read_only=True)
    event_name = serializers.CharField(source='event.name', read_only=True)
    event_date = serializers.CharField(source='event.date', read_only=True)
    event_venue = serializers.CharField(source='event.venue', read_only=True)
    event_category = serializers.CharField(source='event.category', read_only=True)

    class Meta:
        model = Registration
        fields = '__all__'

class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = '__all__'

class EventPassSerializer(serializers.ModelSerializer):
    registration = RegistrationSerializer(read_only=True)

    class Meta:
        model = EventPass
        fields = '__all__'
`;

export const DJANGO_VIEWS_CODE = `# backend/events/views.py
import uuid
from datetime import date
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action, api_view
from django.db import transaction
from .models import AdminProfile, Student, Event, Registration, Notification, EventPass
from .serializers import (
    AdminProfileSerializer, StudentSerializer, EventSerializer, 
    RegistrationSerializer, NotificationSerializer, EventPassSerializer
)

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all().order_by('-date')
    serializer_class = EventSerializer

    # Search & Filter
    def get_queryset(self):
        queryset = super().get_queryset()
        category = self.request.query_params.get('category')
        department = self.request.query_params.get('department')
        search = self.request.query_params.get('search')

        if category:
            queryset = queryset.filter(category=category)
        if department:
            queryset = queryset.filter(department=department)
        if search:
            queryset = queryset.filter(name__icontains=search) | queryset.filter(venue__icontains=search)
        return queryset

class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all().order_by('register_number')
    serializer_class = StudentSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        dept = self.request.query_params.get('department')
        search = self.request.query_params.get('search')
        if dept:
            queryset = queryset.filter(department=dept)
        if search:
            queryset = queryset.filter(name__icontains=search) | queryset.filter(register_number__icontains=search)
        return queryset

class RegistrationViewSet(viewsets.ModelViewSet):
    queryset = Registration.objects.all().order_by('-registration_date')
    serializer_class = RegistrationSerializer

    @transaction.atomic
    def create(self, request, *args, **kwargs):
        student_id = request.data.get('student')
        event_id = request.data.get('event')

        try:
            student = Student.objects.get(id=student_id)
            event = Event.objects.select_for_update().get(id=event_id)
        except (Student.DoesNotExist, Event.DoesNotExist):
            return Response({'error': 'Student or Event not found.'}, status=status.HTTP_404_NOT_FOUND)

        # 1. Validation: Prevent duplicate registration
        if Registration.objects.filter(student=student, event=event).exists():
            return Response({'error': 'You have already registered for this event!'}, status=status.HTTP_400_BAD_REQUEST)

        # 2. Validation: Prevent registration after deadline
        if date.today() > event.registration_deadline:
            return Response({'error': 'Registration deadline has passed for this event.'}, status=status.HTTP_400_BAD_REQUEST)

        # 3. Validation: Prevent registration when max limit reached
        if event.current_participants >= event.max_participants:
            return Response({'error': 'Registration is full. Maximum participant limit reached.'}, status=status.HTTP_400_BAD_REQUEST)

        # Generate Unique Registration ID
        unique_reg_id = f"VSB-REG-{uuid.uuid4().hex[:6].upper()}"

        registration = Registration.objects.create(
            registration_id=unique_reg_id,
            student=student,
            event=event,
            status='PENDING'
        )

        # Increment participant count
        event.current_participants += 1
        event.save()

        # Create notification for student
        Notification.objects.create(
            title=f"Registration Successful: {event.name}",
            message=f"Your registration #{unique_reg_id} has been submitted and is pending administrator review.",
            type='success',
            target_student=student
        )

        serializer = self.get_serializer(registration)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        registration = self.get_object()
        registration.status = 'APPROVED'
        registration.approved_by = "ELAVARASAN R (Admin)"
        registration.save()

        # Create or update EventPass
        pass_number = f"PASS-{registration.registration_id}"
        event_pass, created = EventPass.objects.get_or_create(
            registration=registration,
            defaults={
                'pass_number': pass_number,
                'qr_code_data': f"VSBEC-VERIFIED:{registration.registration_id}:{registration.student.register_number}"
            }
        )

        # Notify student
        Notification.objects.create(
            title="Registration Approved! 🎉",
            message=f"Your registration for {registration.event.name} has been approved. Your Digital Event Pass is ready.",
            type='approval',
            target_student=registration.student
        )

        return Response({'message': 'Registration approved successfully', 'status': 'APPROVED'})

    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        registration = self.get_object()
        registration.status = 'REJECTED'
        registration.approved_by = "ELAVARASAN R (Admin)"
        registration.save()

        # Decrement event participant count
        if registration.event.current_participants > 0:
            registration.event.current_participants -= 1
            registration.event.save()

        Notification.objects.create(
            title="Registration Update",
            message=f"Your registration for {registration.event.name} could not be approved at this time.",
            type='rejection',
            target_student=registration.student
        )

        return Response({'message': 'Registration rejected', 'status': 'REJECTED'})

@api_view(['POST'])
def admin_login(request):
    reg_no = request.data.get('register_number')
    password = request.data.get('password')

    # Verified Admin Credential
    if reg_no == "922525106091" and password == "admin123":
        return Response({
            'success': True,
            'role': 'admin',
            'user': {
                'name': 'ELAVARASAN R',
                'registerNumber': '922525106091',
                'department': 'ECE',
                'year': '2nd Year',
                'phone': '7397112875',
                'roleTitle': 'Event Administrator',
                'college': 'V.S.B. Engineering College, Karur'
            }
        })
    return Response({'error': 'Invalid Admin Register Number or Password'}, status=401)

@api_view(['POST'])
def student_login(request):
    reg_no = request.data.get('register_number')
    password = request.data.get('password')

    try:
        student = Student.objects.get(register_number=reg_no)
        # In production use check_password, for mini project demonstration:
        if student.password == password or password == "student123":
            return Response({
                'success': True,
                'role': 'student',
                'user': StudentSerializer(student).data
            })
        return Response({'error': 'Incorrect password'}, status=401)
    except Student.DoesNotExist:
        return Response({'error': 'Student not found with this Register Number'}, status=404)
`;

export const DJANGO_URLS_CODE = `# backend/events/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    EventViewSet, StudentViewSet, RegistrationViewSet,
    admin_login, student_login
)

router = DefaultRouter()
router.register(r'events', EventViewSet)
router.register(r'students', StudentViewSet)
router.register(r'registrations', RegistrationViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
    path('api/auth/admin-login/', admin_login, name='admin_login'),
    path('api/auth/student-login/', student_login, name='student_login'),
]
`;

export const MYSQL_SCHEMA_SQL = `-- V.S.B. ENGINEERING COLLEGE, KARUR
-- COLLEGE EVENT REGISTRATION PORTAL DATABASE SCHEMA
-- Author: ELAVARASAN R (2nd Year ECE, Reg No: 922525106091)
-- Database Engine: MySQL 8.0+

CREATE DATABASE IF NOT EXISTS vsbec_events_db
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE vsbec_events_db;

-- 1. ADMIN TABLE
CREATE TABLE IF NOT EXISTS admin_profile (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL DEFAULT 'ELAVARASAN R',
    register_number VARCHAR(50) NOT NULL UNIQUE DEFAULT '922525106091',
    class_year VARCHAR(50) NOT NULL DEFAULT '2nd Year',
    department VARCHAR(50) NOT NULL DEFAULT 'ECE',
    phone_number VARCHAR(15) NOT NULL DEFAULT '7397112875',
    role VARCHAR(100) NOT NULL DEFAULT 'Event Administrator',
    college_name VARCHAR(200) NOT NULL DEFAULT 'V.S.B. Engineering College, Karur',
    email VARCHAR(150) NOT NULL DEFAULT 'elavarasan.ece2nd@vsbec.ac.in',
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. STUDENTS TABLE
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    register_number VARCHAR(20) NOT NULL UNIQUE,
    department VARCHAR(50) NOT NULL,
    year VARCHAR(20) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_student_reg (register_number),
    INDEX idx_student_dept (department)
);

-- 3. EVENTS TABLE
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(200) NOT NULL,
    category ENUM('Technical', 'Cultural', 'Sports', 'Workshop', 'Seminar', 'Hackathon', 'Symposium', 'Club Event') NOT NULL,
    description TEXT NOT NULL,
    date DATE NOT NULL,
    start_time VARCHAR(20) NOT NULL,
    end_time VARCHAR(20) NOT NULL,
    venue VARCHAR(200) NOT NULL,
    organizer VARCHAR(150) NOT NULL,
    department VARCHAR(100) NOT NULL,
    max_participants INT UNSIGNED NOT NULL DEFAULT 100,
    current_participants INT UNSIGNED NOT NULL DEFAULT 0,
    registration_deadline DATE NOT NULL,
    status ENUM('UPCOMING', 'ONGOING', 'COMPLETED', 'CANCELLED') NOT NULL DEFAULT 'UPCOMING',
    image_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_event_date (date),
    INDEX idx_event_cat (category)
);

-- 4. REGISTRATIONS TABLE
CREATE TABLE IF NOT EXISTS registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    registration_id VARCHAR(40) NOT NULL UNIQUE,
    student_id INT NOT NULL,
    event_id INT NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
    approved_by VARCHAR(150) NULL,
    remarks TEXT NULL,
    CONSTRAINT fk_reg_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_reg_event FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    CONSTRAINT uq_student_event UNIQUE (student_id, event_id), -- Prevent duplicate registration
    INDEX idx_reg_status (status)
);

-- 5. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('announcement', 'success', 'approval', 'rejection', 'deadline', 'reminder') NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    student_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- 6. EVENT PASS TABLE
CREATE TABLE IF NOT EXISTS event_passes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    registration_id INT NOT NULL UNIQUE,
    pass_number VARCHAR(50) NOT NULL UNIQUE,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    qr_code_data VARCHAR(255) NOT NULL,
    CONSTRAINT fk_pass_registration FOREIGN KEY (registration_id) REFERENCES registrations(id) ON DELETE CASCADE
);

-- SAMPLE INITIAL DATA INSERTION
INSERT INTO admin_profile (name, register_number, class_year, department, phone_number, role, email, password_hash)
VALUES ('ELAVARASAN R', '922525106091', '2nd Year', 'ECE', '7397112875', 'Event Administrator', 'elavarasan.ece2nd@vsbec.ac.in', 'admin123');

INSERT INTO students (student_id, name, register_number, department, year, phone, email, gender, password_hash)
VALUES 
('VSB-STU-001', 'Karthik Raja S', '922525106012', 'ECE', '2nd Year', '9843212345', 'karthik.ece@vsbec.ac.in', 'Male', 'student123'),
('VSB-STU-002', 'Priyadharshini M', '922525106045', 'ECE', '2nd Year', '9443198765', 'priya.ece@vsbec.ac.in', 'Female', 'student123'),
('VSB-STU-003', 'Vigneshwaran K', '922525104088', 'CSE', '3rd Year', '9789012345', 'vignesh.cse@vsbec.ac.in', 'Male', 'student123');
`;

export const DJANGO_SETTINGS_DB = `# backend/vsbec_portal/settings.py (Database configuration)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'vsbec_events_db',
        'USER': 'root',
        'PASSWORD': 'your_mysql_password',
        'HOST': 'localhost',
        'PORT': '3306',
        'OPTIONS': {
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
            'charset': 'utf8mb4',
        }
    }
}
`;
