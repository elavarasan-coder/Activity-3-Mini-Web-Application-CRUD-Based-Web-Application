export type EventCategory = 
  | 'Technical'
  | 'Cultural'
  | 'Sports'
  | 'Workshop'
  | 'Seminar'
  | 'Innovation'
  | 'Hackathon'
  | 'Symposium'
  | 'Club Event';

export type EventStatus = 'UPCOMING' | 'ONGOING' | 'COMPLETED' | 'CANCELLED';

export type RegistrationStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface EventItem {
  id: string;
  eventId: string; // e.g. "EVT-2026-001"
  name: string;
  category: EventCategory;
  description: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:MM AM/PM
  endTime: string;
  venue: string;
  organizer: string;
  department: string;
  maxParticipants: number;
  currentParticipants: number;
  registrationDeadline: string; // YYYY-MM-DD
  status: EventStatus;
  image: string;
  featured?: boolean;
  coordinatorContact?: string;
  rules?: string[];
  prizes?: string;
}

export interface Student {
  id: string;
  studentId: string; // e.g. "VSB-STU-101"
  name: string;
  registerNumber: string; // e.g. "922525106001"
  department: string; // e.g. "ECE", "CSE", "IT", "MECH", "EEE", "AIDS"
  year: string; // "1st Year", "2nd Year", "3rd Year", "4th Year"
  phone: string;
  email: string;
  gender: 'Male' | 'Female' | 'Other';
  createdDate?: string;
}

export interface Registration {
  id: string;
  registrationId: string; // e.g. "VSB-REG-8921"
  studentName: string;
  registerNumber: string;
  department: string;
  year: string;
  phone: string;
  email: string;
  eventId: string;
  eventName: string;
  eventDate: string;
  eventVenue: string;
  eventCategory: EventCategory;
  registrationDate: string; // YYYY-MM-DD HH:mm
  status: RegistrationStatus;
  approvedBy?: string;
  remarks?: string;
}

export interface AdminProfile {
  name: string;
  registerNumber: string;
  classYear: string;
  department: string;
  phone: string;
  role: string;
  college: string;
  email: string;
  bio?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'announcement' | 'success' | 'approval' | 'rejection' | 'deadline' | 'reminder';
  date: string;
  read: boolean;
  targetRole?: 'all' | 'student' | 'admin';
  targetRegNo?: string;
  relatedEventId?: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  role: 'admin' | 'student' | 'guest';
  user: {
    name: string;
    registerNumber: string;
    department?: string;
    year?: string;
    email?: string;
    phone?: string;
    roleTitle?: string;
  } | null;
}
