import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Users, Calendar, ClipboardCheck, Flame, CheckCircle, 
  Clock, TrendingUp, Sparkles, BarChart3, PieChart, 
  Shield, Check, X, ArrowUpRight, Eye, Phone, Mail, Award 
} from 'lucide-react';

export const AdminDashboardView: React.FC = () => {
  const { 
    events, 
    students, 
    registrations, 
    adminProfile, 
    approveRegistration, 
    rejectRegistration,
    setCurrentView,
    setSelectedPassRegistration 
  } = useApp();

  const totalStudents = students.length;
  const totalEvents = events.length;
  const totalRegistrations = registrations.length;
  const upcomingEvents = events.filter(e => e.status === 'UPCOMING').length;
  const confirmedRegistrations = registrations.filter(r => r.status === 'APPROVED').length;
  const pendingRegistrations = registrations.filter(r => r.status === 'PENDING').length;

  // Department-wise registration breakdown
  const deptCounts: Record<string, number> = {};
  registrations.forEach(r => {
    deptCounts[r.department] = (deptCounts[r.department] || 0) + 1;
  });

  // Event-wise participation breakdown
  const eventCounts = events.map(e => ({
    name: e.name,
    category: e.category,
    count: e.currentParticipants,
    max: e.maxParticipants,
    pct: Math.min(100, Math.round((e.currentParticipants / e.maxParticipants) * 100))
  }));

  const recentRegistrations = registrations.slice(0, 5);

  return (
    <div className="space-y-8 pb-16">
      
      {/* Top Welcome Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] border border-violet-500/30 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-violet-600/30 text-violet-200 border border-violet-500/40">
                Administrative Suite
              </span>
              <span className="text-xs text-[#F4D06F] font-bold">
                VSBEC EVENTVERSE
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white font-heading mt-2">
              Event Management & Live Analytics
            </h1>
            <p className="text-xs text-neutral-300 mt-1 max-w-xl">
              Administrator: <strong className="text-[#F4D06F]">{adminProfile.name}</strong> • Register No: <strong className="text-white font-mono-num">{adminProfile.registerNumber}</strong> ({adminProfile.department} - {adminProfile.classYear})
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentView('events-manage')}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] hover:from-[#6D28D9] hover:to-[#A21CAF] text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-violet-900/50 border border-violet-400/40 transition-all"
            >
              + Create New Event
            </button>
            <button
              onClick={() => setCurrentView('registrations-manage')}
              className="px-4 py-2.5 rounded-2xl bg-[#21113D]/60 hover:bg-[#21113D] text-[#F4D06F] font-bold text-xs uppercase tracking-wider border border-violet-500/30 hover:border-violet-400 transition-all"
            >
              Review All ({pendingRegistrations} Pending)
            </button>
          </div>
        </div>
      </div>

      {/* 6 STATISTIC CARDS (Aurora Luxe Theme) */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        
        {/* 1. Total Students */}
        <div className="p-4 rounded-2xl bg-[#0B1026]/90 border border-violet-500/25 hover:border-[#F4D06F] shadow-lg transition-all">
          <div className="flex items-center justify-between text-neutral-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-violet-300">Students</span>
            <Users className="w-4 h-4 text-violet-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono-num">
            {totalStudents}
          </div>
          <div className="text-[10px] text-neutral-400 mt-1 flex items-center gap-1">
            <span className="text-emerald-400 font-bold">● Active</span>
            <span>in Database</span>
          </div>
        </div>

        {/* 2. Total Events */}
        <div className="p-4 rounded-2xl bg-[#0B1026]/90 border border-violet-500/25 hover:border-[#F4D06F] shadow-lg transition-all">
          <div className="flex items-center justify-between text-neutral-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-violet-300">Events</span>
            <Calendar className="w-4 h-4 text-fuchsia-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono-num">
            {totalEvents}
          </div>
          <div className="text-[10px] text-neutral-400 mt-1 flex items-center gap-1">
            <span className="text-[#F4D06F] font-bold">8 Categories</span>
          </div>
        </div>

        {/* 3. Total Registrations */}
        <div className="p-4 rounded-2xl bg-[#0B1026]/90 border border-violet-500/25 hover:border-[#F4D06F] shadow-lg transition-all">
          <div className="flex items-center justify-between text-neutral-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-violet-300">Registrations</span>
            <ClipboardCheck className="w-4 h-4 text-[#F4D06F]" />
          </div>
          <div className="text-2xl font-black text-white font-mono-num">
            {totalRegistrations}
          </div>
          <div className="text-[10px] text-neutral-400 mt-1">
            Submissions
          </div>
        </div>

        {/* 4. Upcoming Events */}
        <div className="p-4 rounded-2xl bg-[#0B1026]/90 border border-violet-500/25 hover:border-violet-400 shadow-lg transition-all">
          <div className="flex items-center justify-between text-neutral-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-violet-300">Upcoming</span>
            <Flame className="w-4 h-4 text-fuchsia-400 fill-fuchsia-400" />
          </div>
          <div className="text-2xl font-black text-fuchsia-400 font-mono-num">
            {upcomingEvents}
          </div>
          <div className="text-[10px] text-neutral-400 mt-1">
            Active on Portal
          </div>
        </div>

        {/* 5. Confirmed Registrations */}
        <div className="p-4 rounded-2xl bg-[#0B1026]/90 border border-violet-500/25 hover:border-emerald-400 shadow-lg transition-all">
          <div className="flex items-center justify-between text-neutral-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-300">Confirmed</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono-num">
            {confirmedRegistrations}
          </div>
          <div className="text-[10px] text-neutral-400 mt-1">
            Passes Generated
          </div>
        </div>

        {/* 6. Pending Registrations */}
        <div className="p-4 rounded-2xl bg-[#0B1026]/90 border border-violet-500/25 hover:border-[#F4D06F] shadow-lg transition-all">
          <div className="flex items-center justify-between text-neutral-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#F4D06F]">Pending</span>
            <Clock className="w-4 h-4 text-[#F4D06F]" />
          </div>
          <div className="text-2xl font-black text-[#F4D06F] font-mono-num">
            {pendingRegistrations}
          </div>
          <div className="text-[10px] text-neutral-400 mt-1">
            Needs Verification
          </div>
        </div>

      </div>

      {/* CHARTS SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* 1. Event-Wise Registrations */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-[#0B1026]/90 border border-violet-500/25 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-violet-400" />
              <h3 className="text-sm font-extrabold text-white uppercase tracking-wider font-heading">
                Event-Wise Registrations & Seat Occupancy
              </h3>
            </div>
            <span className="text-[11px] font-semibold text-neutral-400">
              Live Enrollment
            </span>
          </div>

          <div className="space-y-3.5 pt-2">
            {eventCounts.slice(0, 5).map((item, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-neutral-200 truncate max-w-[280px]">
                    {item.name}
                  </span>
                  <span className="font-mono-num text-[11px] text-neutral-300">
                    <strong className="text-[#F4D06F]">{item.count}</strong> / {item.max} ({item.pct}%)
                  </span>
                </div>
                <div className="h-2 w-full bg-[#21113D] rounded-full overflow-hidden border border-violet-500/20">
                  <div 
                    className="h-full bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#F4D06F] rounded-full transition-all duration-500"
                    style={{ width: `${item.pct}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 2. Department-Wise Participation Chart */}
        <div className="p-6 rounded-3xl bg-[#0B1026]/90 border border-violet-500/25 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <PieChart className="w-4 h-4 text-[#F4D06F]" />
              <h3 className="text-sm font-extrabold text-white uppercase tracking-wider font-heading">
                Department Participation
              </h3>
            </div>
            <span className="text-[11px] text-neutral-400">Ratio</span>
          </div>

          <div className="space-y-3 pt-2">
            {Object.entries(deptCounts).map(([dept, count], i) => {
              const total = registrations.length || 1;
              const pct = Math.round((count / total) * 100);

              return (
                <div key={dept} className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-neutral-300">Dept of {dept}</span>
                    <span className="font-mono-num text-violet-300">{count} ({pct}%)</span>
                  </div>
                  <div className="h-2 bg-[#21113D] rounded-full overflow-hidden border border-violet-500/20">
                    <div 
                      className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500 rounded-full" 
                      style={{ width: `${pct}%` }} 
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* RECENT REGISTRATIONS REVIEW TABLE & ADMIN PROFILE */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Recent Registrations (2 Cols) */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-[#0B1026]/90 border border-violet-500/25 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ClipboardCheck className="w-4 h-4 text-[#F4D06F]" />
              <h3 className="text-sm font-extrabold text-white uppercase tracking-wider font-heading">
                Recent Student Registrations
              </h3>
            </div>
            <button
              onClick={() => setCurrentView('registrations-manage')}
              className="text-xs text-[#F4D06F] font-bold hover:underline"
            >
              View All ({registrations.length}) →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-violet-500/20 text-[10px] text-violet-300 uppercase tracking-wider">
                <tr>
                  <th className="pb-3">Student</th>
                  <th className="pb-3">Event</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right">Quick Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-violet-500/10">
                {recentRegistrations.map((reg) => (
                  <tr key={reg.id} className="hover:bg-violet-950/20 transition-colors">
                    <td className="py-3">
                      <div className="font-bold text-white">{reg.studentName}</div>
                      <div className="text-[10px] text-violet-300 font-mono-num">
                        {reg.registerNumber} • {reg.department}
                      </div>
                    </td>
                    <td className="py-3">
                      <div className="font-semibold text-neutral-200 truncate max-w-[180px]">
                        {reg.eventName}
                      </div>
                      <div className="text-[10px] text-neutral-400 font-mono-num">{reg.registrationId}</div>
                    </td>
                    <td className="py-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        reg.status === 'APPROVED'
                          ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                          : reg.status === 'REJECTED'
                          ? 'bg-rose-950/80 text-rose-300 border border-rose-800/60'
                          : 'bg-amber-950/80 text-[#F4D06F] border border-amber-800/60'
                      }`}>
                        {reg.status}
                      </span>
                    </td>
                    <td className="py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setSelectedPassRegistration(reg);
                            setCurrentView('digital-pass');
                          }}
                          className="p-1.5 rounded-lg bg-violet-950/60 text-violet-300 hover:bg-violet-900 border border-violet-500/30"
                          title="View Pass"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {reg.status === 'PENDING' && (
                          <>
                            <button
                              onClick={() => approveRegistration(reg.id)}
                              className="p-1.5 rounded-lg bg-emerald-950/80 text-emerald-300 hover:bg-emerald-900 border border-emerald-800/50"
                              title="Approve"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => rejectRegistration(reg.id)}
                              className="p-1.5 rounded-lg bg-rose-950/80 text-rose-300 hover:bg-rose-900 border border-rose-800/50"
                              title="Reject"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Administrator Profile Card (1 Col) */}
        <div className="p-6 rounded-3xl bg-gradient-to-b from-[#21113D] to-[#0B1026] border border-violet-500/30 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#F4D06F]" />
              <h3 className="text-sm font-extrabold text-white uppercase tracking-wider font-heading">
                Admin Profile
              </h3>
            </div>
            <span className="text-[10px] bg-violet-900/60 text-violet-200 px-2 py-0.5 rounded-full font-bold">
              Event Administrator
            </span>
          </div>

          <div className="text-center py-2 space-y-1">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#7C3AED] via-[#C026D3] to-[#F4D06F] p-0.5 mx-auto shadow-lg shadow-purple-950/80 flex items-center justify-center">
              <div className="w-full h-full bg-[#0B1026] rounded-[14px] flex items-center justify-center font-black text-xl text-[#F4D06F]">
                ER
              </div>
            </div>
            <h4 className="text-base font-black text-white pt-1">
              {adminProfile.name}
            </h4>
            <div className="text-xs text-[#F4D06F] font-mono-num font-bold">
              Reg No: {adminProfile.registerNumber}
            </div>
            <div className="text-xs text-violet-300">
              {adminProfile.classYear} • Dept of {adminProfile.department}
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#0B1026]/80 border border-violet-500/20 text-xs space-y-2">
            <div className="flex items-center justify-between text-neutral-300">
              <span className="flex items-center gap-1.5 text-neutral-400">
                <Phone className="w-3.5 h-3.5 text-fuchsia-400" />
                <span>Phone:</span>
              </span>
              <strong className="text-white font-mono-num">+91 {adminProfile.phone}</strong>
            </div>
            <div className="flex items-center justify-between text-neutral-300">
              <span className="flex items-center gap-1.5 text-neutral-400">
                <Mail className="w-3.5 h-3.5 text-[#F4D06F]" />
                <span>Email:</span>
              </span>
              <span className="text-white truncate max-w-[160px]">{adminProfile.email}</span>
            </div>
            <div className="flex items-center justify-between text-neutral-300">
              <span className="flex items-center gap-1.5 text-neutral-400">
                <Award className="w-3.5 h-3.5 text-emerald-400" />
                <span>College:</span>
              </span>
              <span className="text-white truncate max-w-[160px]">VSBEC, Karur</span>
            </div>
          </div>

          <button
            onClick={() => setCurrentView('profile')}
            className="w-full py-2.5 rounded-xl bg-violet-950/60 hover:bg-violet-900/60 text-[#F4D06F] font-bold text-xs uppercase tracking-wider border border-violet-500/30 transition-all text-center"
          >
            Manage Administrator Settings
          </button>
        </div>

      </div>

    </div>
  );
};
