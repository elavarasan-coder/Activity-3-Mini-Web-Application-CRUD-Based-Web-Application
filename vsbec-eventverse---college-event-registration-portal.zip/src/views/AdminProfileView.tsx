import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Shield, User, Phone, Mail, GraduationCap, 
  Building2, Key, Edit3, LogOut, CheckCircle2, Sparkles, X, Award 
} from 'lucide-react';

export const AdminProfileView: React.FC = () => {
  const { adminProfile, updateAdminProfile, logout, showToast, auth, theme } = useApp();

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);

  // Edit Form State
  const [name, setName] = useState(adminProfile.name);
  const [phone, setPhone] = useState(adminProfile.phone);
  const [email, setEmail] = useState(adminProfile.email);
  const [bio, setBio] = useState(adminProfile.bio || '');

  // Change Password State
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');

  const isDark = theme === 'dark';

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateAdminProfile({ name, phone, email, bio });
    setIsEditModalOpen(false);
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPass !== confirmPass) {
      showToast('New passwords do not match.', 'error');
      return;
    }
    if (newPass.length < 6) {
      showToast('Password must be at least 6 characters long.', 'error');
      return;
    }
    showToast('Administrator password updated successfully.', 'success');
    setCurrentPass('');
    setNewPass('');
    setConfirmPass('');
    setIsPasswordModalOpen(false);
  };

  return (
    <div className="space-y-8 pb-16 max-w-4xl mx-auto">
      
      {/* Profile Header Banner with Aurora Luxe Theme */}
      <div className="relative rounded-3xl bg-gradient-to-br from-[#21113D] via-[#0B1026] to-[#0B1026] border-2 border-violet-500/40 p-6 sm:p-10 shadow-2xl overflow-hidden">
        
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-60 h-60 rounded-full bg-[#C026D3]/20 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-6 text-center sm:text-left">
          
          {/* Admin Avatar Badge */}
          <div className="relative">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-br from-[#7C3AED] via-[#C026D3] to-[#F4D06F] p-1 shadow-2xl ring-2 ring-[#F4D06F]/60">
              <div className="w-full h-full bg-[#0B1026] rounded-[20px] flex items-center justify-center text-[#F4D06F] font-black text-2xl tracking-wider">
                ER
              </div>
            </div>
            <div className="absolute -bottom-2 -right-2 p-1.5 rounded-full bg-[#F4D06F] text-[#0B1026] shadow-md" title="Event Administrator">
              <Shield className="w-4 h-4 fill-[#0B1026]" />
            </div>
          </div>

          {/* Profile Name & College Titles */}
          <div className="flex-1 space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-950/80 border border-violet-500/40 text-violet-200 text-xs font-bold uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
              <span>{adminProfile.role}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white font-heading">
              {adminProfile.name}
            </h1>

            <div className="text-sm font-bold text-[#F4D06F]">
              {adminProfile.college}
            </div>

            <p className="text-xs text-neutral-300 max-w-xl leading-relaxed pt-1">
              {adminProfile.bio || 'Chief Event Administrator and Full-Stack Developer for VSBEC EVENTVERSE.'}
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex sm:flex-col gap-2 shrink-0">
            <button
              onClick={() => setIsEditModalOpen(true)}
              className="px-4 py-2.5 rounded-2xl bg-[#21113D]/70 hover:bg-[#21113D] text-[#F4D06F] text-xs font-bold border border-violet-500/30 hover:border-[#F4D06F] flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Profile</span>
            </button>

            <button
              onClick={() => setIsPasswordModalOpen(true)}
              className="px-4 py-2.5 rounded-2xl bg-[#0B1026]/90 hover:bg-[#21113D]/60 text-neutral-300 text-xs font-semibold border border-violet-500/20 flex items-center justify-center gap-2 transition-all"
            >
              <Key className="w-3.5 h-3.5 text-violet-400" />
              <span>Change Password</span>
            </button>
          </div>

        </div>

      </div>

      {/* Official Credentials Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        <div className="p-5 rounded-2xl bg-[#0B1026]/90 border border-violet-500/25 space-y-1">
          <span className="text-[10px] text-violet-400 uppercase font-bold tracking-wider">
            Register Number
          </span>
          <div className="text-lg font-black text-[#F4D06F] font-mono-num">
            {adminProfile.registerNumber}
          </div>
          <p className="text-[11px] text-neutral-400">
            Official VSBEC / Anna University Permanent Register Number
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#0B1026]/90 border border-violet-500/25 space-y-1">
          <span className="text-[10px] text-violet-400 uppercase font-bold tracking-wider">
            Academic Class & Department
          </span>
          <div className="text-lg font-black text-white">
            {adminProfile.classYear} • Dept of {adminProfile.department}
          </div>
          <p className="text-[11px] text-neutral-400">
            Electronics and Communication Engineering (ECE)
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#0B1026]/90 border border-violet-500/25 space-y-1">
          <span className="text-[10px] text-violet-400 uppercase font-bold tracking-wider">
            Official Contact Phone
          </span>
          <div className="text-base font-bold text-white font-mono-num flex items-center gap-2">
            <Phone className="w-4 h-4 text-fuchsia-400" />
            <span>+91 {adminProfile.phone}</span>
          </div>
          <p className="text-[11px] text-neutral-400">
            Available for student event assistance & administrative helpline
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#0B1026]/90 border border-violet-500/25 space-y-1">
          <span className="text-[10px] text-violet-400 uppercase font-bold tracking-wider">
            Official College Email
          </span>
          <div className="text-base font-bold text-white truncate flex items-center gap-2">
            <Mail className="w-4 h-4 text-[#F4D06F]" />
            <span>{adminProfile.email}</span>
          </div>
          <p className="text-[11px] text-neutral-400">
            Authorized administrative mailbox for event notifications
          </p>
        </div>

      </div>

      {/* Session Security */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-rose-950/40 via-[#21113D] to-[#0B1026] border border-violet-500/30 flex items-center justify-between">
        <div>
          <h4 className="text-sm font-bold text-white">Session Security</h4>
          <p className="text-xs text-neutral-400">Sign out of administrator session to protect student records.</p>
        </div>
        <button
          onClick={logout}
          className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-rose-950 transition-all"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out Session</span>
        </button>
      </div>

      {/* Edit Profile Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-[#0B1026] border-2 border-violet-500/50 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-violet-500/20">
              <h3 className="text-base font-bold text-white font-heading">Edit Administrator Profile</h3>
              <button onClick={() => setIsEditModalOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateProfile} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Admin Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Phone Number</label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-mono-num"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Admin Bio</label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full bg-[#21113D]/60 text-white rounded-xl p-3 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-violet-500/20">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white font-bold uppercase tracking-wider"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {isPasswordModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-[#0B1026] border-2 border-violet-500/50 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-violet-500/20">
              <h3 className="text-base font-bold text-white font-heading">Change Password</h3>
              <button onClick={() => setIsPasswordModalOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleChangePassword} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Current Password</label>
                <input
                  type="password"
                  required
                  placeholder="admin123"
                  value={currentPass}
                  onChange={(e) => setCurrentPass(e.target.value)}
                  className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">New Password</label>
                <input
                  type="password"
                  required
                  placeholder="Minimum 6 characters"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Confirm New Password</label>
                <input
                  type="password"
                  required
                  placeholder="Re-enter new password"
                  value={confirmPass}
                  onChange={(e) => setConfirmPass(e.target.value)}
                  className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-violet-500/20">
                <button
                  type="button"
                  onClick={() => setIsPasswordModalOpen(false)}
                  className="px-4 py-2 text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white font-bold uppercase tracking-wider"
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
