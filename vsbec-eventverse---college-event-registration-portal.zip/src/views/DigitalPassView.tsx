import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DigitalEventPass } from '../components/DigitalEventPass';
import { Search, Ticket, ShieldCheck, CheckCircle2, Sparkles } from 'lucide-react';
import { Registration } from '../types';

export const DigitalPassView: React.FC = () => {
  const { registrations, selectedPassRegistration, setSelectedPassRegistration, setCurrentView } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchedReg, setSearchedReg] = useState<Registration | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setHasSearched(true);
    const query = searchQuery.trim().toLowerCase();
    const found = registrations.find(
      r => r.registrationId.toLowerCase() === query || 
           r.registerNumber.toLowerCase() === query
    );
    if (found) {
      setSearchedReg(found);
      setSelectedPassRegistration(found);
    } else {
      setSearchedReg(null);
    }
  };

  const activePass = searchedReg || selectedPassRegistration || registrations.find(r => r.status === 'APPROVED') || null;

  return (
    <div className="space-y-8 pb-16">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] p-6 sm:p-8 rounded-3xl border border-violet-500/30 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-bold text-[#F4D06F] uppercase tracking-widest flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
            <span>V.S.B. ENGINEERING COLLEGE, KARUR</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            VSBEC EVENTVERSE • Digital Event Pass
          </h1>
          <p className="text-xs text-neutral-300 mt-1 max-w-xl">
            Official gate entry pass authorized by Admin ELAVARASAN R. Download, save, print, or share your deterministic QR pass to present at the event hall entrance.
          </p>
        </div>

        <button
          onClick={() => setCurrentView('my-events')}
          className="px-4 py-2.5 rounded-2xl bg-[#21113D]/60 hover:bg-[#21113D] text-[#F4D06F] text-xs font-bold border border-violet-500/30 hover:border-violet-400 flex items-center gap-2 self-start md:self-auto transition-all"
        >
          <Ticket className="w-4 h-4 text-[#F4D06F]" />
          <span>My Registrations</span>
        </button>
      </div>

      {/* Quick Pass Search / Gate Verification Bar */}
      <div className="bg-[#0B1026]/90 p-5 rounded-3xl border border-violet-500/30 max-w-2xl mx-auto shadow-2xl space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#F4D06F]" />
            <span>Search / Verify Any Student Pass</span>
          </span>
          <span className="text-[11px] text-neutral-400">
            By Pass ID or College Reg No
          </span>
        </div>

        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-violet-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="e.g. VSB-REG-2026-001 or 922525106091"
              className="w-full bg-[#21113D]/40 text-white text-xs rounded-xl pl-10 pr-4 py-3 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-mono-num"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-3 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#C026D3] hover:opacity-90 text-white text-xs font-bold uppercase tracking-wider border border-violet-400/40"
          >
            Verify Pass
          </button>
        </form>

        {hasSearched && !searchedReg && (
          <p className="text-xs text-rose-400 bg-rose-950/40 p-2.5 rounded-xl border border-rose-900/50">
            No registration pass matched query: "{searchQuery}". Please check the Registration ID or Register Number.
          </p>
        )}
      </div>

      {/* Digital Pass Card */}
      <DigitalEventPass registrationOverride={activePass} />

    </div>
  );
};
