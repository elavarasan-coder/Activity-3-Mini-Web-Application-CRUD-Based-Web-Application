import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { EventItem, EventCategory, EventStatus } from '../types';
import { 
  Plus, Edit2, Trash2, Calendar, MapPin, 
  Search, Eye, Clock, Users, X, Check, AlertCircle, Sparkles 
} from 'lucide-react';

export const EventManagementView: React.FC = () => {
  const { events, addEvent, updateEvent, deleteEvent } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<EventItem | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  // Form State
  const [formData, setFormData] = useState({
    eventId: '',
    name: '',
    category: 'Technical' as EventCategory,
    description: '',
    date: '',
    startTime: '09:00 AM',
    endTime: '04:30 PM',
    venue: '',
    organizer: '',
    department: 'ECE',
    maxParticipants: 100,
    registrationDeadline: '',
    status: 'UPCOMING' as EventStatus,
    image: '',
    featured: false
  });

  const categories: EventCategory[] = [
    'Technical', 'Cultural', 'Sports', 'Workshop', 'Seminar', 'Hackathon', 'Symposium', 'Club Event', 'Innovation'
  ];

  const handleOpenAdd = () => {
    const nextNum = events.length + 1;
    setEditingEvent(null);
    setFormData({
      eventId: `VSB-EVT-${nextNum < 10 ? '00' + nextNum : '0' + nextNum}`,
      name: '',
      category: 'Technical',
      description: '',
      date: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
      startTime: '09:30 AM',
      endTime: '04:30 PM',
      venue: 'ECE Seminar Hall, VSBEC Campus',
      organizer: 'Department of ECE',
      department: 'ECE',
      maxParticipants: 120,
      registrationDeadline: new Date(Date.now() + 12 * 86400000).toISOString().split('T')[0],
      status: 'UPCOMING',
      image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=900&q=80',
      featured: false
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (evt: EventItem) => {
    setEditingEvent(evt);
    setFormData({
      eventId: evt.eventId,
      name: evt.name,
      category: evt.category,
      description: evt.description,
      date: evt.date,
      startTime: evt.startTime,
      endTime: evt.endTime,
      venue: evt.venue,
      organizer: evt.organizer,
      department: evt.department,
      maxParticipants: evt.maxParticipants,
      registrationDeadline: evt.registrationDeadline,
      status: evt.status,
      image: evt.image,
      featured: Boolean(evt.featured)
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.venue.trim() || !formData.organizer.trim()) {
      alert('Please fill all mandatory event fields.');
      return;
    }

    if (editingEvent) {
      updateEvent(editingEvent.id, formData);
    } else {
      addEvent(formData);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete event "${name}"? This action cannot be undone.`)) {
      deleteEvent(id);
    }
  };

  const filtered = events.filter(e => {
    const matchesSearch = 
      e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.eventId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.venue.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = categoryFilter === 'All' || e.category === categoryFilter;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-6 pb-16">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] p-6 rounded-3xl border border-violet-500/30 shadow-xl">
        <div>
          <span className="text-[10px] font-bold text-[#F4D06F] uppercase tracking-widest flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
            <span>CRUD EVENT ADMINISTRATION • VSBEC EVENTVERSE</span>
          </span>
          <h1 className="text-2xl font-black text-white font-heading mt-1">
            Event Management Suite
          </h1>
          <p className="text-xs text-neutral-300 mt-1">
            Publish, edit, monitor capacity, and archive events organized by V.S.B. Engineering College departments.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] hover:from-[#6D28D9] hover:to-[#A21CAF] text-white font-extrabold text-xs uppercase tracking-wider shadow-xl shadow-violet-900/50 border border-violet-400/40 hover:scale-105 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-[#F4D06F]" />
          <span>Add New Event</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-violet-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search event ID, name, venue..."
            className="w-full bg-[#0B1026] text-white text-xs rounded-xl pl-10 pr-4 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="bg-[#0B1026] text-neutral-200 text-xs rounded-xl px-4 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-semibold"
        >
          <option value="All">All Categories ({events.length})</option>
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Events Table */}
      <div className="bg-[#0B1026]/90 rounded-3xl border border-violet-500/30 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-300 min-w-[800px]">
            <thead className="bg-[#21113D]/60 text-[10px] uppercase font-bold text-violet-300 tracking-wider border-b border-violet-500/20">
              <tr>
                <th className="py-3.5 px-4">Event ID</th>
                <th className="py-3.5 px-4">Event Details</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Date & Time</th>
                <th className="py-3.5 px-4">Venue</th>
                <th className="py-3.5 px-4">Capacity</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-violet-500/10">
              {filtered.map(evt => (
                <tr key={evt.id} className="hover:bg-violet-950/20 transition-colors">
                  <td className="py-3.5 px-4 font-mono-num font-bold text-fuchsia-400">
                    {evt.eventId}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-extrabold text-white text-sm">{evt.name}</div>
                    <div className="text-[11px] text-neutral-400 truncate max-w-xs">{evt.department} • {evt.organizer}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-full bg-violet-900/40 border border-violet-500/30 text-[#F4D06F] font-bold text-[10px]">
                      {evt.category}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-neutral-200">{evt.date}</div>
                    <div className="text-[10px] text-violet-300/80">{evt.startTime}</div>
                  </td>
                  <td className="py-3.5 px-4 text-neutral-300 max-w-[180px] truncate">
                    {evt.venue}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="font-mono-num font-bold text-[#F4D06F]">{evt.currentParticipants}</span>
                    <span className="text-neutral-500 font-mono-num"> / {evt.maxParticipants}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase border ${
                      evt.status === 'UPCOMING'
                        ? 'bg-violet-950/80 text-violet-300 border-violet-500/40'
                        : evt.status === 'ONGOING'
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                        : 'bg-neutral-900 text-neutral-400 border-neutral-700'
                    }`}>
                      {evt.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleOpenEdit(evt)}
                        className="p-1.5 rounded-xl bg-[#21113D]/60 hover:bg-[#21113D] text-[#F4D06F] border border-violet-500/30 transition-colors"
                        title="Edit Event"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(evt.id, evt.name)}
                        className="p-1.5 rounded-xl bg-[#21113D]/60 hover:bg-rose-950 text-rose-400 border border-violet-500/30 hover:border-rose-500 transition-colors"
                        title="Delete Event"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* CRUD Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-[#0B1026] border-2 border-violet-500/50 rounded-3xl shadow-2xl overflow-hidden my-8">
            
            <div className="bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] px-6 py-4 border-b border-violet-500/30 flex items-center justify-between">
              <div>
                <h3 className="text-base font-extrabold text-white font-heading">
                  {editingEvent ? 'Edit Event Details' : 'Create New College Event'}
                </h3>
                <span className="text-[11px] text-[#F4D06F] font-bold">
                  V.S.B. Engineering College, Karur • VSBEC EVENTVERSE
                </span>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-neutral-400 hover:text-white rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Event ID *</label>
                  <input
                    type="text"
                    required
                    value={formData.eventId}
                    onChange={(e) => setFormData({ ...formData, eventId: e.target.value })}
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-mono-num"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Event Category *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as EventCategory })}
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  >
                    {categories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Event Name *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. ELECTROBLAZE 2026 - National Tech Symposium"
                  className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-semibold"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Description *</label>
                <textarea
                  rows={3}
                  required
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Detailed rules, eligibility, round information..."
                  className="w-full bg-[#21113D]/60 text-white rounded-xl p-3 border border-violet-500/30 focus:border-[#F4D06F] outline-none leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Start Time *</label>
                  <input
                    type="text"
                    required
                    value={formData.startTime}
                    onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                    placeholder="09:30 AM"
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">End Time *</label>
                  <input
                    type="text"
                    required
                    value={formData.endTime}
                    onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                    placeholder="04:30 PM"
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Venue *</label>
                  <input
                    type="text"
                    required
                    value={formData.venue}
                    onChange={(e) => setFormData({ ...formData, venue: e.target.value })}
                    placeholder="e.g. ECE Seminar Hall, Block C"
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Organizer & Department *</label>
                  <input
                    type="text"
                    required
                    value={formData.organizer}
                    onChange={(e) => setFormData({ ...formData, organizer: e.target.value })}
                    placeholder="e.g. Department of ECE"
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Max Participants *</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={formData.maxParticipants}
                    onChange={(e) => setFormData({ ...formData, maxParticipants: parseInt(e.target.value) || 50 })}
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-mono-num"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Registration Deadline *</label>
                  <input
                    type="date"
                    required
                    value={formData.registrationDeadline}
                    onChange={(e) => setFormData({ ...formData, registrationDeadline: e.target.value })}
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Event Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as EventStatus })}
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  >
                    <option value="UPCOMING">UPCOMING</option>
                    <option value="ONGOING">ONGOING</option>
                    <option value="COMPLETED">COMPLETED</option>
                    <option value="CANCELLED">CANCELLED</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Event Image URL</label>
                <input
                  type="url"
                  value={formData.image}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="featured-evt"
                  checked={formData.featured}
                  onChange={(e) => setFormData({ ...formData, featured: e.target.checked })}
                  className="rounded border-violet-500/40 text-[#7C3AED] focus:ring-violet-500 bg-[#21113D] w-4 h-4"
                />
                <label htmlFor="featured-evt" className="font-semibold text-neutral-300 cursor-pointer">
                  Feature this event on Home Page Banner
                </label>
              </div>

              <div className="pt-3 flex justify-end gap-3 border-t border-violet-500/20">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-neutral-400 hover:text-white font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] text-white font-bold uppercase tracking-wider border border-violet-400/40 shadow-lg shadow-violet-950"
                >
                  {editingEvent ? 'Save Changes' : 'Publish Event'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
