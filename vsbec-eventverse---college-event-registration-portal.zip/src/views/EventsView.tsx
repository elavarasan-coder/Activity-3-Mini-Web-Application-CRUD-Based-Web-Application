import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { EventCard } from '../components/EventCard';
import { RegistrationModal } from '../components/RegistrationModal';
import { EventItem, EventCategory } from '../types';
import { Search, Filter, Calendar, MapPin, Building, RotateCcw, Sparkles } from 'lucide-react';

export const EventsView: React.FC = () => {
  const { events, setSelectedPassRegistration } = useApp();

  const [selectedEventForReg, setSelectedEventForReg] = useState<EventItem | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [departmentFilter, setDepartmentFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  const categories: string[] = [
    'All',
    'Technical',
    'Cultural',
    'Sports',
    'Workshop',
    'Seminar',
    'Hackathon',
    'Symposium',
    'Club Event',
    'Innovation'
  ];

  const departments: string[] = [
    'All',
    'ECE',
    'CSE',
    'IT',
    'AIDS',
    'EEE',
    'MECH',
    'CIVIL',
    'All Departments'
  ];

  const filteredEvents = events.filter(e => {
    const matchesSearch = 
      e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.venue.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.organizer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.eventId.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = categoryFilter === 'All' || e.category === categoryFilter;
    const matchesDept = departmentFilter === 'All' || e.department.includes(departmentFilter);
    const matchesStatus = statusFilter === 'All' || e.status === statusFilter;

    return matchesSearch && matchesCategory && matchesDept && matchesStatus;
  });

  const handleResetFilters = () => {
    setSearchTerm('');
    setCategoryFilter('All');
    setDepartmentFilter('All');
    setStatusFilter('All');
  };

  return (
    <div className="space-y-8 pb-16">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] p-6 sm:p-8 rounded-3xl border border-violet-500/30 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-bold text-[#F4D06F] uppercase tracking-widest flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
            <span>V.S.B. ENGINEERING COLLEGE, KARUR • VSBEC EVENTVERSE</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            College Events, Contests & Symposiums
          </h1>
          <p className="text-xs text-neutral-300 mt-1 max-w-xl">
            Explore academic symposia, national hackathons, innovation challenges, workshops, and sports meets. Register online to generate your instant QR entry pass.
          </p>
        </div>

        <div className="p-3.5 bg-[#0B1026]/90 rounded-2xl border border-violet-500/30 text-xs text-neutral-300 space-y-1">
          <div className="text-[10px] text-[#F4D06F] font-bold uppercase tracking-wider">
            Total Live Events
          </div>
          <div className="text-2xl font-black text-white font-mono-num">
            {events.length}
          </div>
          <div className="text-[10px] text-violet-300">
            Open for all VSBEC students
          </div>
        </div>
      </div>

      {/* Filter and Search Controls Bar */}
      <div className="bg-[#0B1026]/90 p-5 rounded-3xl border border-violet-500/30 space-y-4 shadow-xl">
        
        {/* Top search */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-violet-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by event name, venue, organizer, or ID..."
              className="w-full bg-[#21113D]/40 text-white text-xs rounded-xl pl-10 pr-4 py-3 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
            />
          </div>

          <button
            onClick={handleResetFilters}
            className="flex items-center justify-center gap-1.5 px-4 py-3 rounded-xl bg-[#21113D]/60 hover:bg-[#21113D] text-xs font-semibold text-neutral-300 border border-violet-500/30 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#F4D06F]" />
            <span>Reset</span>
          </button>
        </div>

        {/* Dropdowns row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-violet-500/20">
          <div>
            <label className="block text-[10px] font-bold text-violet-300 uppercase mb-1">
              Category
            </label>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full bg-[#21113D]/60 text-neutral-200 text-xs rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-medium"
            >
              {categories.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-violet-300 uppercase mb-1">
              Department
            </label>
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="w-full bg-[#21113D]/60 text-neutral-200 text-xs rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-medium"
            >
              {departments.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-violet-300 uppercase mb-1">
              Status
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full bg-[#21113D]/60 text-neutral-200 text-xs rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-medium"
            >
              <option value="All">All Statuses</option>
              <option value="UPCOMING">Upcoming</option>
              <option value="ONGOING">Ongoing</option>
              <option value="COMPLETED">Completed</option>
            </select>
          </div>
        </div>

      </div>

      {/* Events Results Count */}
      <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
        <span>Showing <strong className="text-white">{filteredEvents.length}</strong> of {events.length} events</span>
        {filteredEvents.length < events.length && (
          <span className="text-[#F4D06F] font-semibold">Filters applied</span>
        )}
      </div>

      {/* Events Grid */}
      {filteredEvents.length === 0 ? (
        <div className="p-16 text-center bg-[#21113D]/20 rounded-3xl border border-violet-500/20 space-y-3">
          <Calendar className="w-12 h-12 text-violet-400/60 mx-auto" />
          <h3 className="text-base font-bold text-white font-heading">No Events Found</h3>
          <p className="text-xs text-neutral-400 max-w-sm mx-auto">
            Try adjusting your search terms or filter selection to see other college events.
          </p>
          <button
            onClick={handleResetFilters}
            className="px-4 py-2 rounded-xl bg-[#21113D] text-xs font-semibold text-[#F4D06F] hover:bg-[#21113D]/80 border border-violet-500/30"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map(evt => (
            <EventCard
              key={evt.id}
              event={evt}
              onRegister={(e) => setSelectedEventForReg(e)}
            />
          ))}
        </div>
      )}

      {/* Registration Modal */}
      {selectedEventForReg && (
        <RegistrationModal
          event={selectedEventForReg}
          onClose={() => setSelectedEventForReg(null)}
          onSuccess={(reg) => {
            setSelectedPassRegistration(reg);
          }}
        />
      )}

    </div>
  );
};
