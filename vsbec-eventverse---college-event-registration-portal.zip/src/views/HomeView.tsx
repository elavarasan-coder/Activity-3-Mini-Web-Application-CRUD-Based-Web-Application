import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { EventCard } from '../components/EventCard';
import { RegistrationModal } from '../components/RegistrationModal';
import { EventItem } from '../types';
import { COLLEGE_ANNOUNCEMENTS } from '../data/mockData';
import { 
  Sparkles, Calendar, Users, Trophy, Award, 
  ArrowRight, Clock, ShieldCheck, Flame, Bell, 
  Search, ChevronRight, CheckCircle2, Ticket,
  Zap, Theater, Lightbulb, Mic, Rocket, Compass, Filter
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const { events, registrations, setCurrentView, setSelectedPassRegistration, theme } = useApp();

  const [selectedEventForReg, setSelectedEventForReg] = useState<EventItem | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const isDark = theme === 'dark';

  // Flagship countdown timer
  const [timeLeft, setTimeLeft] = useState({
    days: 27,
    hours: 11,
    minutes: 42,
    seconds: 15
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Event Categories requested in prompt
  const categoryCards = [
    {
      id: 'Technical',
      title: 'Technical',
      icon: Zap,
      desc: 'Hackathons, coding competitions, symposiums',
      color: 'from-violet-600 to-indigo-600',
      border: 'border-violet-500/40',
      iconColor: 'text-violet-400'
    },
    {
      id: 'Cultural',
      title: 'Cultural',
      icon: Theater,
      desc: 'Dance, music, drama and cultural programs',
      color: 'from-pink-600 to-fuchsia-600',
      border: 'border-pink-500/40',
      iconColor: 'text-pink-400'
    },
    {
      id: 'Sports',
      title: 'Sports',
      icon: Trophy,
      desc: 'Indoor and outdoor sports events & meets',
      color: 'from-emerald-600 to-teal-600',
      border: 'border-emerald-500/40',
      iconColor: 'text-emerald-400'
    },
    {
      id: 'Workshop',
      title: 'Workshop',
      icon: Lightbulb,
      desc: 'Hands-on technical engineering workshops',
      color: 'from-amber-500 to-yellow-600',
      border: 'border-amber-500/40',
      iconColor: 'text-[#F4D06F]'
    },
    {
      id: 'Seminar',
      title: 'Seminar',
      icon: Mic,
      desc: 'Expert talks, guest lectures & research colloquiums',
      color: 'from-cyan-600 to-blue-600',
      border: 'border-cyan-500/40',
      iconColor: 'text-cyan-400'
    },
    {
      id: 'Innovation',
      title: 'Innovation',
      icon: Rocket,
      desc: 'Projects, startup MVPs and innovation expos',
      color: 'from-purple-600 to-fuchsia-600',
      border: 'border-fuchsia-500/40',
      iconColor: 'text-fuchsia-400'
    },
  ];

  const featuredEvents = events.filter(e => e.featured);
  const popularEvents = [...events].sort((a, b) => b.currentParticipants - a.currentParticipants).slice(0, 3);
  const upcomingEvents = events.filter(e => e.status === 'UPCOMING');

  const filteredEvents = events.filter(e => {
    const matchesCat = activeCategory === 'All' || e.category === activeCategory || 
      (activeCategory === 'Technical' && (e.category === 'Symposium' || e.category === 'Hackathon'));
    const matchesSearch = 
      e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.venue.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.department.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-14 pb-20">
      
      {/* 1. HERO SECTION */}
      <section className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-[#21113D]/90 via-[#0B1026] to-[#0B1026] border border-violet-500/30 shadow-2xl p-6 sm:p-12 text-center lg:text-left">
        
        {/* Animated Aurora Glow Orbs */}
        <div className="absolute -top-10 left-1/3 w-96 h-96 rounded-full bg-[#7C3AED]/25 blur-[120px] pointer-events-none aurora-glow-1" />
        <div className="absolute -bottom-10 right-10 w-96 h-96 rounded-full bg-[#C026D3]/20 blur-[130px] pointer-events-none aurora-glow-2" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Hero Text */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Tagline / Eyebrow */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-violet-950/80 border border-violet-500/40 text-violet-200 text-xs font-bold uppercase tracking-widest shadow-lg">
              <Sparkles className="w-3.5 h-3.5 text-[#F4D06F] animate-spin" />
              <span>V.S.B. ENGINEERING COLLEGE, KARUR</span>
            </div>

            {/* Main Headline */}
            <div className="space-y-2">
              <p className="text-sm sm:text-base font-extrabold uppercase tracking-widest text-[#F4D06F]">
                Experience Campus Life Differently
              </p>
              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black font-heading tracking-tight text-white leading-tight">
                VSBEC <br className="hidden sm:block" />
                <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-[#F4D06F] bg-clip-text text-transparent">
                  EVENTVERSE
                </span>
              </h1>
              <p className="text-base sm:text-lg font-bold text-violet-300">
                College Event Registration Portal
              </p>
            </div>

            <p className="text-xs sm:text-sm text-neutral-300 max-w-xl leading-relaxed">
              Connect • Create • Participate • Celebrate. The centralized hub for state-level symposiums, 24-hr hackathons, robotics challenges, hands-on labs, and automated digital QR entry passes.
            </p>

            {/* Buttons: Explore Events & Register Now */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2">
              <button
                onClick={() => setCurrentView('events')}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] hover:from-[#6D28D9] hover:to-[#A21CAF] text-white font-extrabold text-xs uppercase tracking-wider shadow-xl shadow-violet-950/60 border border-violet-400/40 hover:border-[#F4D06F] transition-all duration-300 flex items-center gap-2 group"
              >
                <Compass className="w-4 h-4 text-[#F4D06F] transition-transform group-hover:rotate-45" />
                <span>Explore Events</span>
              </button>

              <button
                onClick={() => {
                  const firstOpen = events.find(e => e.status === 'UPCOMING' && e.currentParticipants < e.maxParticipants);
                  if (firstOpen) setSelectedEventForReg(firstOpen);
                }}
                className="px-6 py-3 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] text-[#F4D06F] font-extrabold text-xs uppercase tracking-wider border border-[#F4D06F]/40 hover:border-[#F4D06F] transition-all flex items-center gap-2"
              >
                <span>Register Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Admin Developer Footnote */}
            <div className="pt-2 flex items-center justify-center lg:justify-start gap-2 text-[11px] text-violet-300">
              <ShieldCheck className="w-4 h-4 text-[#F4D06F]" />
              <span>Admin: <strong>ELAVARASAN R</strong> (2nd Year ECE | Reg: 922525106091)</span>
            </div>

          </div>

          {/* Right Hero: Countdown to Flagship Symposium */}
          <div className="lg:col-span-5">
            <div className="rounded-3xl p-6 sm:p-7 bg-[#21113D]/70 border border-violet-500/40 shadow-2xl backdrop-blur-2xl space-y-5">
              
              <div className="flex items-center justify-between border-b border-violet-500/20 pb-4">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#F4D06F] flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-fuchsia-400" />
                    Flagship Symposium
                  </span>
                  <h3 className="text-base font-extrabold text-white mt-1">
                    ELECTROBLAZE 2026
                  </h3>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-violet-600/30 text-violet-300 border border-violet-500/30">
                  Dept of ECE
                </span>
              </div>

              {/* Countdown Clocks */}
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="p-3 rounded-2xl bg-[#0B1026]/90 border border-violet-500/30">
                  <div className="text-xl sm:text-2xl font-black font-mono-num text-[#F4D06F]">
                    {String(timeLeft.days).padStart(2, '0')}
                  </div>
                  <div className="text-[9px] uppercase font-bold text-neutral-400 mt-1">Days</div>
                </div>

                <div className="p-3 rounded-2xl bg-[#0B1026]/90 border border-violet-500/30">
                  <div className="text-xl sm:text-2xl font-black font-mono-num text-white">
                    {String(timeLeft.hours).padStart(2, '0')}
                  </div>
                  <div className="text-[9px] uppercase font-bold text-neutral-400 mt-1">Hours</div>
                </div>

                <div className="p-3 rounded-2xl bg-[#0B1026]/90 border border-violet-500/30">
                  <div className="text-xl sm:text-2xl font-black font-mono-num text-white">
                    {String(timeLeft.minutes).padStart(2, '0')}
                  </div>
                  <div className="text-[9px] uppercase font-bold text-neutral-400 mt-1">Mins</div>
                </div>

                <div className="p-3 rounded-2xl bg-[#0B1026]/90 border border-violet-500/30">
                  <div className="text-xl sm:text-2xl font-black font-mono-num text-fuchsia-400">
                    {String(timeLeft.seconds).padStart(2, '0')}
                  </div>
                  <div className="text-[9px] uppercase font-bold text-neutral-400 mt-1">Secs</div>
                </div>
              </div>

              <div className="text-xs text-neutral-300 space-y-1.5 pt-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-400">Venue:</span>
                  <span className="font-semibold text-white">ECE Seminar Hall & Block-C Labs</span>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-400">Prizes:</span>
                  <span className="font-semibold text-[#F4D06F]">₹25,000 Cash + Rolling Trophy</span>
                </div>
              </div>

              <button
                onClick={() => {
                  const electroblaze = events[0];
                  if (electroblaze) setSelectedEventForReg(electroblaze);
                }}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-extrabold text-xs uppercase tracking-wider shadow-lg shadow-violet-950 flex items-center justify-center gap-2 transition-all border border-violet-400/40"
              >
                <span>Instant Registration for Flagship</span>
                <ArrowRight className="w-4 h-4 text-[#F4D06F]" />
              </button>

            </div>
          </div>

        </div>

      </section>

      {/* 2. EVENT CATEGORIES CARDS (per prompt) */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#F4D06F]">
              Browse By Domain
            </span>
            <h2 className="text-xl sm:text-2xl font-black font-heading text-white">
              Featured Event Categories
            </h2>
          </div>
          <p className="text-xs text-neutral-400">
            Click any category to filter available competitions
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {categoryCards.map(cat => {
            const Icon = cat.icon;
            const isSelected = activeCategory === cat.id;

            return (
              <div
                key={cat.id}
                onClick={() => {
                  setActiveCategory(isSelected ? 'All' : cat.id);
                }}
                className={`p-5 rounded-3xl backdrop-blur-xl border cursor-pointer transition-all duration-300 transform hover:-translate-y-1 group relative overflow-hidden ${
                  isSelected
                    ? 'bg-[#21113D] border-[#F4D06F] shadow-xl shadow-purple-950/60 ring-1 ring-[#F4D06F]'
                    : 'bg-[#0B1026]/80 border-violet-500/20 hover:border-violet-400 hover:bg-[#21113D]/40'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${cat.color} p-0.5 shadow-md flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform`}>
                    <div className="w-full h-full bg-[#0B1026] rounded-[14px] flex items-center justify-center">
                      <Icon className={`w-6 h-6 ${cat.iconColor}`} />
                    </div>
                  </div>

                  <div className="space-y-1 flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-black text-white group-hover:text-[#F4D06F] transition-colors">
                        {cat.title}
                      </h3>
                      <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-[#F4D06F] group-hover:translate-x-1 transition-all" />
                    </div>
                    <p className="text-xs text-neutral-300 leading-relaxed">
                      {cat.desc}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. FEATURED EVENTS */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#7C3AED] to-[#C026D3] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-[#F4D06F]" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black font-heading text-white">
                Featured Flagship Events
              </h2>
              <p className="text-xs text-neutral-400">
                Top high-stake symposiums and national competitions at VSBEC
              </p>
            </div>
          </div>

          <button
            onClick={() => setCurrentView('events')}
            className="hidden sm:flex items-center gap-1.5 text-xs font-bold text-[#F4D06F] hover:underline"
          >
            <span>View All ({events.length})</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredEvents.slice(0, 3).map(event => (
            <EventCard
              key={event.id}
              event={event}
              onRegister={(evt) => setSelectedEventForReg(evt)}
            />
          ))}
        </div>
      </section>

      {/* 4. POPULAR EVENTS */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-fuchsia-600 to-pink-600 flex items-center justify-center">
              <Flame className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black font-heading text-white">
                Popular & High Demand Events
              </h2>
              <p className="text-xs text-neutral-400">
                Trending programs filling up quickly across departments
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {popularEvents.map(event => (
            <EventCard
              key={event.id}
              event={event}
              onRegister={(evt) => setSelectedEventForReg(evt)}
            />
          ))}
        </div>
      </section>

      {/* 5. UPCOMING EVENTS (with Category & Search Filters) */}
      <section className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-black font-heading text-white">
              All Upcoming Events
            </h2>
            <p className="text-xs text-neutral-400">
              Showing {filteredEvents.length} events scheduled for 2026 Academic Calendar
            </p>
          </div>

          {/* Search Bar */}
          <div className="relative max-w-sm w-full">
            <Search className="w-4 h-4 text-violet-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search event name, venue, department..."
              className="w-full bg-[#21113D]/40 text-white rounded-xl pl-10 pr-4 py-2.5 text-xs border border-violet-500/30 focus:border-[#F4D06F] outline-none"
            />
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {['All', 'Technical', 'Hackathon', 'Symposium', 'Workshop', 'Cultural', 'Sports', 'Seminar', 'Innovation'].map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-md shadow-violet-950 border border-violet-400/50'
                  : 'bg-[#21113D]/40 text-neutral-300 border border-violet-500/20 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {filteredEvents.length === 0 ? (
          <div className="p-12 text-center rounded-3xl bg-[#21113D]/20 border border-violet-500/20 space-y-3">
            <Compass className="w-8 h-8 text-violet-400 mx-auto opacity-60" />
            <h3 className="text-sm font-bold text-white">No matching events found</h3>
            <p className="text-xs text-neutral-400">Try adjusting your search query or category filter.</p>
            <button
              onClick={() => { setActiveCategory('All'); setSearchQuery(''); }}
              className="px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-bold"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map(event => (
              <EventCard
                key={event.id}
                event={event}
                onRegister={(evt) => setSelectedEventForReg(evt)}
              />
            ))}
          </div>
        )}
      </section>

      {/* 6. LATEST ANNOUNCEMENTS (per prompt) */}
      <section className="rounded-3xl p-6 sm:p-8 bg-[#21113D]/40 border border-violet-500/20 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-[#F4D06F]" />
            <h3 className="text-sm font-black uppercase tracking-wider text-white font-heading">
              Latest College Announcements & Circulars
            </h3>
          </div>
          <span className="text-[10px] text-violet-300 font-bold uppercase">
            Office of Event Administrator
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {COLLEGE_ANNOUNCEMENTS.slice(0, 3).map((ann, idx) => (
            <div key={idx} className="p-4 rounded-2xl bg-[#0B1026]/90 border border-violet-500/20 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-[#F4D06F] uppercase tracking-wider">
                  {ann.tag}
                </span>
                <span className="text-[10px] text-neutral-400 font-mono-num">{ann.date}</span>
              </div>
              <h4 className="font-bold text-white leading-snug">
                {ann.title}
              </h4>
              <p className="text-[11px] text-violet-300 leading-relaxed">
                Dept: {ann.department}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Registration Modal */}
      {selectedEventForReg && (
        <RegistrationModal
          event={selectedEventForReg}
          onClose={() => setSelectedEventForReg(null)}
          onSuccess={(reg) => {
            setSelectedEventForReg(null);
            setSelectedPassRegistration(reg);
            setCurrentView('digital-pass');
          }}
        />
      )}

    </div>
  );
};
