import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Shield, Eye, EyeOff, Lock, User, 
  Sparkles, ArrowRight, GraduationCap, CheckCircle2,
  Calendar, Award, Compass
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const { loginAdmin, loginStudent, adminProfile, showToast, setCurrentView, theme } = useApp();

  const [activeTab, setActiveTab] = useState<'admin' | 'student'>('admin');
  const [registerNumber, setRegisterNumber] = useState('922525106091');
  const [password, setPassword] = useState('admin123');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  const isDark = theme === 'dark';

  const handleAdminAutofill = () => {
    setActiveTab('admin');
    setRegisterNumber('922525106091');
    setPassword('admin123');
    showToast('Admin credentials autofilled: ELAVARASAN R (922525106091)', 'info');
  };

  const handleStudentAutofill = () => {
    setActiveTab('student');
    setRegisterNumber('922525106012');
    setPassword('student123');
    showToast('Student credentials autofilled: Karthik Raja S (922525106012)', 'info');
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!registerNumber.trim() || !password.trim()) {
      showToast('Please enter both Register Number and Password.', 'error');
      return;
    }

    if (activeTab === 'admin') {
      const success = loginAdmin(registerNumber.trim(), password.trim());
      if (success) {
        setCurrentView('dashboard');
      }
    } else {
      const success = loginStudent(registerNumber.trim(), password.trim());
      if (success) {
        setCurrentView('home');
      }
    }
  };

  return (
    <div className="min-h-[85vh] py-8 flex items-center justify-center relative">
      
      {/* Background Aurora Orbs */}
      <div className="absolute top-10 left-1/4 w-96 h-96 rounded-full bg-[#7C3AED]/20 blur-[120px] pointer-events-none aurora-glow-1" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 rounded-full bg-[#C026D3]/20 blur-[130px] pointer-events-none aurora-glow-2" />

      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 rounded-3xl overflow-hidden border border-violet-500/30 shadow-2xl shadow-purple-950/60 bg-[#0B1026]/90 backdrop-blur-2xl relative z-10">
        
        {/* LEFT SIDE: VSBEC EVENTVERSE Hero Branding */}
        <div className="lg:col-span-6 p-8 sm:p-12 bg-gradient-to-br from-[#21113D]/90 via-[#0B1026] to-[#0B1026] border-b lg:border-b-0 lg:border-r border-violet-500/20 flex flex-col justify-between relative overflow-hidden">
          
          {/* Subtle Accent Glow */}
          <div className="absolute -top-16 -left-16 w-56 h-56 rounded-full bg-[#C026D3]/25 blur-2xl pointer-events-none" />

          {/* Top College Badge */}
          <div className="space-y-4 relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-violet-950/80 border border-violet-500/40 text-violet-300 text-[10px] font-bold uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
              <span>V.S.B. ENGINEERING COLLEGE, KARUR</span>
            </div>

            <div className="space-y-2">
              <h1 className="text-3xl sm:text-4xl font-black font-heading tracking-tight text-white leading-tight">
                VSBEC <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-[#F4D06F] bg-clip-text text-transparent">EVENTVERSE</span>
              </h1>
              <p className="text-xs font-extrabold uppercase tracking-widest text-[#F4D06F]">
                College Event Registration Portal
              </p>
              <p className="text-sm italic text-violet-200/90 font-medium">
                Connect • Create • Participate • Celebrate
              </p>
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed max-w-md pt-2">
              Welcome to the centralized university event gateway. Browse academic symposiums, national 24-hr hackathons, hands-on engineering workshops, cultural fests, and instant QR entry passes.
            </p>
          </div>

          {/* Highlights Grid */}
          <div className="my-8 grid grid-cols-2 gap-3 relative z-10">
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-violet-500/20 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                <Award className="w-4 h-4 text-[#F4D06F]" />
                <span>NAAC 'A' Grade</span>
              </div>
              <p className="text-[10px] text-neutral-400">Autonomous Engineering Campus</p>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-violet-500/20 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                <Compass className="w-4 h-4 text-violet-400" />
                <span>Real-Time Passes</span>
              </div>
              <p className="text-[10px] text-neutral-400">Deterministic QR Verification</p>
            </div>
          </div>

          {/* Developer & Admin Pill */}
          <div className="p-4 rounded-2xl bg-[#21113D]/60 border border-violet-500/30 space-y-1 relative z-10">
            <div className="flex items-center justify-between text-[10px] uppercase font-bold text-[#F4D06F] tracking-wider">
              <span>Event Administrator</span>
              <Shield className="w-3.5 h-3.5 text-[#F4D06F]" />
            </div>
            <div className="text-sm font-black text-white">
              {adminProfile.name}
            </div>
            <div className="text-[11px] text-violet-300 font-mono-num">
              Reg No: {adminProfile.registerNumber} • 2nd Year ECE
            </div>
            <div className="text-[10px] text-neutral-400">
              V.S.B. Engineering College, Karur
            </div>
          </div>

        </div>

        {/* RIGHT SIDE: Admin & Student Login */}
        <div className="lg:col-span-6 p-8 sm:p-12 flex flex-col justify-between space-y-6">
          
          <div className="space-y-6">
            
            {/* Header with Role Selection Tabs */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-xl sm:text-2xl font-black font-heading text-white">
                  {activeTab === 'admin' ? 'Admin Login' : 'Student Login'}
                </h2>
                <span className="text-[11px] text-violet-300 font-medium">
                  {activeTab === 'admin' ? 'Administrative Suite' : 'Student Access'}
                </span>
              </div>

              {/* Tabs */}
              <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-[#21113D]/70 border border-violet-500/30">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('admin');
                    setRegisterNumber('922525106091');
                    setPassword('admin123');
                  }}
                  className={`py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                    activeTab === 'admin'
                      ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-md shadow-purple-950 border border-violet-300/40'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <Shield className="w-3.5 h-3.5 text-[#F4D06F]" />
                  <span>Admin Login</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('student');
                    setRegisterNumber('922525106012');
                    setPassword('student123');
                  }}
                  className={`py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                    activeTab === 'student'
                      ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-md shadow-purple-950 border border-violet-300/40'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <GraduationCap className="w-3.5 h-3.5 text-violet-300" />
                  <span>Student Login</span>
                </button>
              </div>
            </div>

            {/* Quick Demo Credentials Autofill */}
            <div className="p-3 rounded-2xl bg-white/[0.02] border border-violet-500/20 space-y-2">
              <div className="flex items-center justify-between text-[10px] text-violet-400 font-bold uppercase tracking-wider">
                <span>⚡ Quick 1-Click Credentials</span>
                <span className="text-[#F4D06F]">Evaluation Ready</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleAdminAutofill}
                  className="px-3 py-1.5 rounded-xl bg-violet-950/60 hover:bg-violet-900/60 text-[#F4D06F] text-[11px] font-bold border border-violet-500/30 flex items-center justify-center gap-1.5 transition-all truncate"
                >
                  <Shield className="w-3 h-3 text-[#F4D06F] shrink-0" />
                  <span className="truncate">Admin (ELAVARASAN)</span>
                </button>
                <button
                  type="button"
                  onClick={handleStudentAutofill}
                  className="px-3 py-1.5 rounded-xl bg-fuchsia-950/40 hover:bg-fuchsia-900/40 text-fuchsia-200 text-[11px] font-bold border border-fuchsia-500/30 flex items-center justify-center gap-1.5 transition-all truncate"
                >
                  <GraduationCap className="w-3 h-3 text-fuchsia-300 shrink-0" />
                  <span className="truncate">Student (Karthik R)</span>
                </button>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1.5">
                  Register Number
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-violet-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    required
                    value={registerNumber}
                    onChange={(e) => setRegisterNumber(e.target.value)}
                    placeholder="e.g. 922525106091"
                    className="w-full bg-[#21113D]/40 text-white rounded-xl pl-10 pr-4 py-3 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-mono-num transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-neutral-300 mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-violet-400 absolute left-3.5 top-3.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-[#21113D]/40 text-white rounded-xl pl-10 pr-10 py-3 border border-violet-500/30 focus:border-[#F4D06F] outline-none transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3.5 text-neutral-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember Me & Help */}
              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-neutral-400 text-xs select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded border-violet-500/40 bg-[#21113D] text-violet-600 focus:ring-violet-500"
                  />
                  <span>Remember Me</span>
                </label>

                <span 
                  onClick={() => showToast('For Admin: 922525106091 / admin123 | For Student: 922525106012 / student123', 'info')}
                  className="text-[11px] text-[#F4D06F] hover:underline cursor-pointer"
                >
                  Forgot Password?
                </span>
              </div>

              {/* Glowing violet login button with subtle gold hover effect */}
              <button
                type="submit"
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] hover:from-[#6D28D9] hover:to-[#A21CAF] text-white font-extrabold text-xs uppercase tracking-wider shadow-lg shadow-violet-900/60 border border-violet-400/40 hover:border-[#F4D06F] hover:shadow-[#F4D06F]/20 hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 group"
              >
                <span>Login to {activeTab === 'admin' ? 'Admin Portal' : 'Student Portal'}</span>
                <ArrowRight className="w-4 h-4 text-[#F4D06F] transition-transform group-hover:translate-x-1" />
              </button>
            </form>

          </div>

          {/* College Branding Footer */}
          <div className="pt-4 border-t border-violet-500/20 text-center text-[11px] text-neutral-400 space-y-1">
            <div className="font-semibold text-white">
              V.S.B. ENGINEERING COLLEGE, KARUR
            </div>
            <div className="text-violet-300 text-[10px]">
              COLLEGE EVENT REGISTRATION PORTAL • Mini Project
            </div>
            <div className="text-[10px] text-[#F4D06F] font-mono-num pt-0.5">
              Admin: ELAVARASAN R (2nd Year ECE | Reg No: 922525106091)
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
