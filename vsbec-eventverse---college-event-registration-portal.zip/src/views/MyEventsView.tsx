import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Registration } from '../types';
import { 
  ClipboardList, Ticket, Calendar, MapPin, 
  Clock, CheckCircle, AlertTriangle, XCircle, ArrowRight, Sparkles 
} from 'lucide-react';

export const MyEventsView: React.FC = () => {
  const { registrations, auth, setSelectedPassRegistration, setCurrentView, theme } = useApp();

  const [activeTab, setActiveTab] = useState<'ALL' | 'APPROVED' | 'PENDING' | 'REJECTED'>('ALL');

  const studentRegs = auth.role === 'student' && auth.user?.registerNumber
    ? registrations.filter(r => r.registerNumber.toLowerCase() === auth.user?.registerNumber.toLowerCase())
    : registrations;

  const filteredRegs = studentRegs.filter(r => {
    if (activeTab === 'ALL') return true;
    return r.status === activeTab;
  });

  return (
    <div className="space-y-6 pb-16">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] p-6 sm:p-8 rounded-3xl border border-violet-500/30 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-bold text-[#F4D06F] uppercase tracking-widest flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
            <span>VSBEC EVENTVERSE • STUDENT PORTAL</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            My Registered Events & Passes
          </h1>
          <p className="text-xs text-neutral-300 mt-1">
            Track your event registration submissions, check confirmation status, and access your digital QR gate passes.
          </p>
        </div>

        <button
          onClick={() => setCurrentView('events')}
          className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] hover:from-[#6D28D9] hover:to-[#A21CAF] text-white font-extrabold text-xs uppercase tracking-wider shadow-xl shadow-violet-900/50 border border-violet-400/40 hover:scale-105 transition-all self-start md:self-auto"
        >
          <span>Explore More Events</span>
          <ArrowRight className="w-4 h-4 text-[#F4D06F]" />
        </button>
      </div>

      {/* Tabs Filter */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
        {[
          { id: 'ALL', label: `All Registrations (${studentRegs.length})` },
          { id: 'APPROVED', label: `Confirmed & Passes (${studentRegs.filter(r => r.status === 'APPROVED').length})` },
          { id: 'PENDING', label: `Pending (${studentRegs.filter(r => r.status === 'PENDING').length})` },
          { id: 'REJECTED', label: `Rejected (${studentRegs.filter(r => r.status === 'REJECTED').length})` },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${
              activeTab === tab.id
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-lg shadow-violet-950 border border-violet-400/40'
                : 'bg-[#21113D]/40 text-neutral-300 border border-violet-500/20 hover:border-violet-500/40'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Registrations List */}
      {filteredRegs.length === 0 ? (
        <div className="p-16 text-center bg-[#21113D]/20 rounded-3xl border border-violet-500/20 space-y-3">
          <ClipboardList className="w-12 h-12 text-violet-400/60 mx-auto" />
          <h3 className="text-base font-bold text-white font-heading">No Registrations in this Category</h3>
          <p className="text-xs text-neutral-400 max-w-sm mx-auto">
            You haven't registered for any events matching this filter. Browse upcoming college symposiums, hackathons, and workshops to register.
          </p>
          <button
            onClick={() => setCurrentView('events')}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white font-bold text-xs uppercase tracking-wider"
          >
            Browse College Events
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredRegs.map(reg => {
            const isApproved = reg.status === 'APPROVED';
            const isPending = reg.status === 'PENDING';
            const isRejected = reg.status === 'REJECTED';

            return (
              <div 
                key={reg.id}
                className="p-6 rounded-3xl bg-[#0B1026]/90 border border-violet-500/25 hover:border-[#F4D06F] shadow-xl flex flex-col justify-between space-y-4 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-mono-num font-black text-fuchsia-400 bg-violet-950/80 px-2.5 py-0.5 rounded-lg border border-violet-500/30">
                      {reg.registrationId}
                    </span>
                    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                      isApproved 
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                        : isPending 
                        ? 'bg-amber-950/80 text-[#F4D06F] border-amber-500/40'
                        : 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                    }`}>
                      {isApproved && <CheckCircle className="w-3 h-3" />}
                      {isPending && <Clock className="w-3 h-3" />}
                      {isRejected && <XCircle className="w-3 h-3" />}
                      <span>{reg.status}</span>
                    </span>
                  </div>

                  <h3 className="text-base sm:text-lg font-black text-white font-heading leading-snug">
                    {reg.eventName}
                  </h3>

                  <div className="space-y-1.5 mt-3 pt-3 border-t border-violet-500/20 text-xs text-neutral-300">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-fuchsia-400 shrink-0" />
                      <span>Event Date: <strong className="text-white">{reg.eventDate}</strong></span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[#F4D06F] shrink-0" />
                      <span className="truncate">Venue: {reg.eventVenue}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-violet-300/80 pt-1 font-mono-num">
                      <span>Submitted: {reg.registrationDate}</span>
                    </div>
                  </div>
                </div>

                {/* Bottom Action */}
                <div className="pt-2 border-t border-violet-500/20">
                  {isApproved ? (
                    <button
                      onClick={() => {
                        setSelectedPassRegistration(reg);
                        setCurrentView('digital-pass');
                      }}
                      className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-violet-950 border border-violet-400/40 hover:border-[#F4D06F] flex items-center justify-center gap-2 transition-all"
                    >
                      <Ticket className="w-4 h-4 text-[#F4D06F]" />
                      <span>View & Print Digital Event Pass</span>
                    </button>
                  ) : isPending ? (
                    <div className="p-2.5 rounded-xl bg-[#21113D]/50 text-[#F4D06F] text-center text-xs font-semibold border border-violet-500/20">
                      ⏳ Pending Approval by Administrator ELAVARASAN R
                    </div>
                  ) : (
                    <div className="p-2.5 rounded-xl bg-rose-950/40 text-rose-300 text-center text-xs font-semibold border border-rose-900/40">
                      ❌ Registration Not Confirmed (Event Capacity Reached or Criteria Mismatch)
                    </div>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
