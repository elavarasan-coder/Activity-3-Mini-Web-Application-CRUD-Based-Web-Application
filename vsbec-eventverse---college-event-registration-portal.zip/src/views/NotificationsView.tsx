import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Bell, CheckCircle2, AlertCircle, Calendar, 
  Clock, Check, Sparkles, Filter, Trash2 
} from 'lucide-react';

export const NotificationsView: React.FC = () => {
  const { 
    notifications, 
    markNotificationAsRead, 
    markAllNotificationsAsRead, 
    setCurrentView 
  } = useApp();

  const [filterType, setFilterType] = useState<string>('all');

  const filtered = notifications.filter(n => {
    if (filterType === 'all') return true;
    if (filterType === 'unread') return !n.read;
    return n.type === filterType;
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="space-y-6 pb-16 max-w-4xl mx-auto">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] p-6 sm:p-8 rounded-3xl border border-violet-500/30 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-[#F4D06F] uppercase tracking-widest flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
              <span>LIVE ALERT CENTER • VSBEC EVENTVERSE</span>
            </span>
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white animate-pulse">
                {unreadCount} Unread
              </span>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            Portal Notifications & Announcements
          </h1>
          <p className="text-xs text-neutral-300 mt-1">
            Instant updates regarding event announcements, registration status, pass approvals, and college deadlines.
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={markAllNotificationsAsRead}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-[#21113D]/60 hover:bg-[#21113D] text-[#F4D06F] text-xs font-bold border border-violet-500/30 hover:border-violet-400 transition-all self-start sm:self-auto"
          >
            <Check className="w-4 h-4 text-[#F4D06F]" />
            <span>Mark All as Read</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
        {[
          { id: 'all', label: 'All Notifications' },
          { id: 'unread', label: `Unread (${unreadCount})` },
          { id: 'announcement', label: 'Announcements' },
          { id: 'approval', label: 'Pass Approvals' },
          { id: 'deadline', label: 'Deadlines & Reminders' },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setFilterType(t.id)}
            className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${
              filterType === t.id
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-lg shadow-violet-950 border border-violet-400/40'
                : 'bg-[#21113D]/40 text-neutral-300 border border-violet-500/20 hover:border-violet-500/40'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Notifications Card List */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="p-12 text-center bg-[#21113D]/20 rounded-3xl border border-violet-500/20">
            <Bell className="w-10 h-10 text-violet-400/60 mx-auto mb-2" />
            <p className="text-xs text-neutral-400">No notifications found for this filter.</p>
          </div>
        ) : (
          filtered.map(notif => {
            const isApproval = notif.type === 'approval' || notif.type === 'success';
            const isDeadline = notif.type === 'deadline';
            const isRejection = notif.type === 'rejection';

            return (
              <div
                key={notif.id}
                onClick={() => markNotificationAsRead(notif.id)}
                className={`p-4 sm:p-5 rounded-3xl border transition-all cursor-pointer flex gap-4 items-start ${
                  !notif.read
                    ? 'bg-[#21113D]/60 border-violet-500/50 shadow-lg shadow-purple-950/40'
                    : 'bg-[#0B1026]/90 border-violet-500/20 hover:border-violet-500/40'
                }`}
              >
                {/* Icon Badge */}
                <div className={`p-2.5 rounded-2xl shrink-0 mt-0.5 ${
                  isApproval
                    ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/40'
                    : isDeadline
                    ? 'bg-amber-950/80 text-[#F4D06F] border border-amber-500/40'
                    : isRejection
                    ? 'bg-rose-950/80 text-rose-400 border border-rose-500/40'
                    : 'bg-violet-950/80 text-violet-300 border border-violet-500/40'
                }`}>
                  {isApproval && <CheckCircle2 className="w-5 h-5" />}
                  {isDeadline && <Calendar className="w-5 h-5" />}
                  {isRejection && <AlertCircle className="w-5 h-5" />}
                  {!isApproval && !isDeadline && !isRejection && <Sparkles className="w-5 h-5 text-[#F4D06F]" />}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="text-sm font-extrabold text-white flex items-center gap-2">
                      <span>{notif.title}</span>
                      {!notif.read && (
                        <span className="w-2 h-2 rounded-full bg-[#C026D3] animate-ping" />
                      )}
                    </h4>
                    <span className="text-[11px] text-violet-300/80 whitespace-nowrap font-mono-num">
                      {notif.date}
                    </span>
                  </div>

                  <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
                    {notif.message}
                  </p>

                  {notif.relatedEventId && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setCurrentView('events');
                      }}
                      className="mt-2 text-[11px] font-bold text-[#F4D06F] hover:underline inline-flex items-center gap-1"
                    >
                      <span>Go to Event Details →</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
