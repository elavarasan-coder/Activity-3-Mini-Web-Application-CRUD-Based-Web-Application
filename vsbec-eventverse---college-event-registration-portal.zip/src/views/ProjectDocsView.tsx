import React, { useState } from 'react';
import { 
  DJANGO_MODELS_CODE, 
  DJANGO_SERIALIZERS_CODE, 
  DJANGO_VIEWS_CODE, 
  DJANGO_URLS_CODE, 
  DJANGO_SETTINGS_DB, 
  MYSQL_SCHEMA_SQL 
} from '../data/projectDocs';
import { 
  FileCode, Database, Terminal, BookOpen, 
  Copy, Check, Sparkles, ExternalLink, ShieldCheck, Download 
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ProjectDocsView: React.FC = () => {
  const { showToast } = useApp();
  const [activeTab, setActiveTab] = useState<'django' | 'mysql' | 'setup' | 'viva'>('django');
  const [activeDjangoFile, setActiveDjangoFile] = useState<'models' | 'serializers' | 'views' | 'urls' | 'settings'>('models');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const djangoCodeMap: Record<string, string> = {
    models: DJANGO_MODELS_CODE,
    serializers: DJANGO_SERIALIZERS_CODE,
    views: DJANGO_VIEWS_CODE,
    urls: DJANGO_URLS_CODE,
    settings: DJANGO_SETTINGS_DB,
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    showToast('Code snippet copied to clipboard!', 'success');
    setTimeout(() => setCopiedKey(null), 2500);
  };

  return (
    <div className="space-y-8 pb-16 max-w-6xl mx-auto">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] p-6 sm:p-8 rounded-3xl border border-violet-500/30 shadow-xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-950/80 border border-violet-500/40 text-violet-300 text-[10px] font-bold uppercase tracking-widest">
          <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
          <span>MINI PROJECT TECHNICAL BLUEPRINT • VSBEC EVENTVERSE</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white font-heading">
          Backend Source Code, MySQL Schema & Viva Defense Guide
        </h1>
        <p className="text-xs text-neutral-300 max-w-2xl leading-relaxed">
          Complete production-grade Django REST Framework backend source code, relational MySQL 8.0 DDL schema, deployment commands, and viva defense questions for mini-project presentation at V.S.B. Engineering College, Karur.
        </p>

        <div className="pt-2 flex flex-wrap gap-4 text-xs">
          <div className="p-3 rounded-2xl bg-[#0B1026] border border-violet-500/30 flex items-center gap-2">
            <span className="text-violet-300 font-bold">Event Administrator:</span>
            <span className="text-white font-extrabold">ELAVARASAN R (Reg: 922525106091)</span>
          </div>
          <div className="p-3 rounded-2xl bg-[#0B1026] border border-violet-500/30 flex items-center gap-2">
            <span className="text-violet-300 font-bold">Class & Department:</span>
            <span className="text-[#F4D06F] font-extrabold">2nd Year ECE, VSBEC Karur</span>
          </div>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {[
          { id: 'django', label: 'Django Backend Code', icon: FileCode },
          { id: 'mysql', label: 'MySQL Schema & DDL', icon: Database },
          { id: 'setup', label: 'Installation & Setup', icon: Terminal },
          { id: 'viva', label: 'Viva Q&A Defense', icon: BookOpen },
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`p-3.5 rounded-2xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white shadow-xl shadow-violet-950 border border-violet-400/40'
                  : 'bg-[#0B1026] text-neutral-300 border border-violet-500/20 hover:border-violet-500/40'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB CONTENT: DJANGO BACKEND */}
      {activeTab === 'django' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            {/* Django Sub-file pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
              {[
                { id: 'models', label: 'models.py' },
                { id: 'serializers', label: 'serializers.py' },
                { id: 'views', label: 'views.py' },
                { id: 'urls', label: 'urls.py' },
                { id: 'settings', label: 'settings.py snippet' },
              ].map(sub => (
                <button
                  key={sub.id}
                  onClick={() => setActiveDjangoFile(sub.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
                    activeDjangoFile === sub.id
                      ? 'bg-violet-950 text-[#F4D06F] border border-violet-500/40 shadow'
                      : 'bg-[#0B1026] text-neutral-400 border border-violet-500/20 hover:text-white'
                  }`}
                >
                  {sub.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => copyToClipboard(djangoCodeMap[activeDjangoFile], `django-${activeDjangoFile}`)}
              className="px-4 py-2 rounded-xl bg-[#21113D]/60 hover:bg-[#21113D] text-[#F4D06F] text-xs font-bold border border-violet-500/30 flex items-center gap-1.5 transition-all"
            >
              {copiedKey === `django-${activeDjangoFile}` ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>Copy {activeDjangoFile}.py</span>
            </button>
          </div>

          <div className="relative rounded-3xl bg-[#0B1026] border border-violet-500/30 overflow-hidden shadow-2xl">
            <div className="bg-[#21113D]/60 px-5 py-3 border-b border-violet-500/20 flex items-center justify-between text-xs text-neutral-400 font-mono">
              <span className="text-violet-200">events_backend/api/{activeDjangoFile}.py</span>
              <span className="text-[10px] text-[#F4D06F] font-bold">Python 3.10+ / Django 5.x REST Framework</span>
            </div>
            <pre className="p-6 text-xs text-neutral-200 font-mono overflow-x-auto leading-relaxed max-h-[550px] scrollbar-thin">
              <code>{djangoCodeMap[activeDjangoFile]}</code>
            </pre>
          </div>
        </div>
      )}

      {/* TAB CONTENT: MYSQL SCHEMA */}
      {activeTab === 'mysql' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-heading">
                MySQL 8.0 Relational Database Script (vsbec_events)
              </h3>
              <p className="text-xs text-neutral-400">
                Contains complete DDL schema, foreign key constraints, indexes, and initial VSBEC seed data.
              </p>
            </div>
            <button
              onClick={() => copyToClipboard(MYSQL_SCHEMA_SQL, 'mysql-script')}
              className="px-4 py-2 rounded-xl bg-[#21113D]/60 hover:bg-[#21113D] text-[#F4D06F] text-xs font-bold border border-violet-500/30 flex items-center gap-1.5 transition-all"
            >
              {copiedKey === 'mysql-script' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>Copy SQL Script</span>
            </button>
          </div>

          <div className="relative rounded-3xl bg-[#0B1026] border border-violet-500/30 overflow-hidden shadow-2xl">
            <div className="bg-[#21113D]/60 px-5 py-3 border-b border-violet-500/20 flex items-center justify-between text-xs text-neutral-400 font-mono">
              <span className="text-violet-200">database/vsbec_events_schema.sql</span>
              <span className="text-[10px] text-[#F4D06F] font-bold">MySQL InnoDB Engine • UTF8MB4</span>
            </div>
            <pre className="p-6 text-xs text-neutral-200 font-mono overflow-x-auto leading-relaxed max-h-[550px] scrollbar-thin">
              <code>{MYSQL_SCHEMA_SQL}</code>
            </pre>
          </div>
        </div>
      )}

      {/* TAB CONTENT: INSTALLATION GUIDE */}
      {activeTab === 'setup' && (
        <div className="space-y-6">
          <div className="p-6 sm:p-8 rounded-3xl bg-[#0B1026] border border-violet-500/30 space-y-6 text-xs text-neutral-300 shadow-xl">
            <h3 className="text-base font-extrabold text-white font-heading">
              Step-by-Step Local Deployment & Installation Guide
            </h3>

            {/* Step 1 */}
            <div className="space-y-2 p-4 rounded-2xl bg-[#21113D]/40 border border-violet-500/20">
              <h4 className="font-extrabold text-[#F4D06F] text-sm">Step 1: Create Virtual Environment</h4>
              <p className="text-neutral-300">Open your terminal or command prompt and initialize a clean Python virtual environment:</p>
              <pre className="p-3 bg-black/80 rounded-xl text-neutral-200 font-mono border border-violet-500/10">
                <code>python -m venv venv{"\n"}source venv/bin/activate  # On Windows: venv\Scripts\activate</code>
              </pre>
            </div>

            {/* Step 2 */}
            <div className="space-y-2 p-4 rounded-2xl bg-[#21113D]/40 border border-violet-500/20">
              <h4 className="font-extrabold text-[#F4D06F] text-sm">Step 2: Install Django & Dependencies</h4>
              <p className="text-neutral-300">Install Django, Django REST Framework, Django CORS headers, and MySQL client:</p>
              <pre className="p-3 bg-black/80 rounded-xl text-neutral-200 font-mono border border-violet-500/10">
                <code>pip install django djangorestframework django-cors-headers mysqlclient</code>
              </pre>
            </div>

            {/* Step 3 */}
            <div className="space-y-2 p-4 rounded-2xl bg-[#21113D]/40 border border-violet-500/20">
              <h4 className="font-extrabold text-[#F4D06F] text-sm">Step 3: Setup MySQL Database</h4>
              <p className="text-neutral-300">Login to MySQL server and execute the provided SQL script to initialize tables:</p>
              <pre className="p-3 bg-black/80 rounded-xl text-neutral-200 font-mono border border-violet-500/10">
                <code>mysql -u root -p &lt; vsbec_events_schema.sql</code>
              </pre>
            </div>

            {/* Step 4 */}
            <div className="space-y-2 p-4 rounded-2xl bg-[#21113D]/40 border border-violet-500/20">
              <h4 className="font-extrabold text-[#F4D06F] text-sm">Step 4: Run Django Migrations</h4>
              <pre className="p-3 bg-black/80 rounded-xl text-neutral-200 font-mono border border-violet-500/10">
                <code>python manage.py makemigrations{"\n"}python manage.py migrate</code>
              </pre>
            </div>

            {/* Step 5 */}
            <div className="space-y-2 p-4 rounded-2xl bg-[#21113D]/40 border border-violet-500/20">
              <h4 className="font-extrabold text-[#F4D06F] text-sm">Step 5: Launch Django REST Server</h4>
              <pre className="p-3 bg-black/80 rounded-xl text-neutral-200 font-mono border border-violet-500/10">
                <code>python manage.py runserver 8000</code>
              </pre>
              <p className="text-emerald-400 font-semibold pt-1">
                API will be live at: http://localhost:8000/api/events/
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: VIVA QUESTIONS & DEFENSE */}
      {activeTab === 'viva' && (
        <div className="space-y-4">
          <div className="p-6 sm:p-8 rounded-3xl bg-[#0B1026] border border-violet-500/30 space-y-5 text-xs text-neutral-300 shadow-xl">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#F4D06F]" />
              <h3 className="text-base font-extrabold text-white font-heading">
                Mini Project Viva Defense Q&A (Prepared for ELAVARASAN R, Reg No: 922525106091)
              </h3>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-[#21113D]/40 border border-violet-500/20 space-y-1.5">
                <span className="font-extrabold text-[#F4D06F] block text-sm">Q1: What problem does this College Event Registration Portal solve?</span>
                <p className="text-neutral-300 leading-relaxed">
                  <strong>Answer:</strong> In V.S.B. Engineering College, events were previously coordinated using manual paper forms and static Google Forms, which caused registration duplication, lack of real-time seat limit enforcement, delays in admin approvals, and lost entry tickets. Our system automates registration, prevents duplicate entries via composite key checks (student register number + event ID), enforces max participants capacity limits, and instantly issues a printable QR digital event pass.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#21113D]/40 border border-violet-500/20 space-y-1.5">
                <span className="font-extrabold text-[#F4D06F] block text-sm">Q2: How is data integrity guaranteed in the database?</span>
                <p className="text-neutral-300 leading-relaxed">
                  <strong>Answer:</strong> The MySQL relational schema uses a <code className="text-violet-300 font-mono">UNIQUE KEY unique_student_event (student_id, event_id)</code> constraint to guarantee at the database level that no student can double-register for the same event. In addition, transactions and status states (<code className="text-violet-300 font-mono">PENDING, APPROVED, REJECTED</code>) ensure verified candidate attendance.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#21113D]/40 border border-violet-500/20 space-y-1.5">
                <span className="font-extrabold text-[#F4D06F] block text-sm">Q3: How does the Digital Event Pass work?</span>
                <p className="text-neutral-300 leading-relaxed">
                  <strong>Answer:</strong> Each approved registration generates a unique Registration Pass ID (e.g., <code className="text-violet-300 font-mono">VSB-REG-2026-001</code>). The portal computes a deterministic QR hash matrix and prints a formal pass carrying student name, register number, department, event title, date, venue, and authorized administrator signature of ELAVARASAN R.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#21113D]/40 border border-violet-500/20 space-y-1.5">
                <span className="font-extrabold text-[#F4D06F] block text-sm">Q4: Why was Django REST Framework selected for the backend?</span>
                <p className="text-neutral-300 leading-relaxed">
                  <strong>Answer:</strong> Django provides an enterprise-grade Object Relational Mapper (ORM), built-in CSRF protection, secure SQL injection prevention, automatic schema migrations, and fast serialization with DRF for React frontend consumption.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
