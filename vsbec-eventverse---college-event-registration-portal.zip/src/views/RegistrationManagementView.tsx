import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Registration, RegistrationStatus } from '../types';
import { 
  ClipboardList, Search, Filter, Check, X, 
  Trash2, Eye, Ticket, Calendar, User, CheckCircle2, AlertCircle, Sparkles 
} from 'lucide-react';

export const RegistrationManagementView: React.FC = () => {
  const { 
    registrations, 
    events, 
    approveRegistration, 
    rejectRegistration, 
    deleteRegistration,
    setSelectedPassRegistration,
    setCurrentView 
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [eventFilter, setEventFilter] = useState('All');
  const [deptFilter, setDeptFilter] = useState('All');
  const [yearFilter, setYearFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');

  const [selectedDetails, setSelectedDetails] = useState<Registration | null>(null);

  const departments = ['All', 'ECE', 'CSE', 'IT', 'AIDS', 'EEE', 'MECH', 'CIVIL'];
  const years = ['All', '1st Year', '2nd Year', '3rd Year', '4th Year'];

  const filtered = registrations.filter(r => {
    const matchesSearch = 
      r.registrationId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.registerNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.eventName.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesEvent = eventFilter === 'All' || r.eventId === eventFilter;
    const matchesDept = deptFilter === 'All' || r.department === deptFilter;
    const matchesYear = yearFilter === 'All' || r.year === yearFilter;
    const matchesStatus = statusFilter === 'All' || r.status === statusFilter;

    return matchesSearch && matchesEvent && matchesDept && matchesYear && matchesStatus;
  });

  const handleDelete = (id: string, regId: string) => {
    if (confirm(`Are you sure you want to delete registration #${regId}?`)) {
      deleteRegistration(id);
    }
  };

  return (
    <div className="space-y-6 pb-16">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] p-6 rounded-3xl border border-violet-500/30 shadow-xl">
        <div>
          <span className="text-[10px] font-bold text-[#F4D06F] uppercase tracking-widest flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
            <span>APPLICATIONS & PASSES • VSBEC EVENTVERSE</span>
          </span>
          <h1 className="text-2xl font-black text-white font-heading mt-1">
            Registration Management
          </h1>
          <p className="text-xs text-neutral-300 mt-1">
            Review student registrations, verify credentials, issue digital QR passes, and oversee attendance.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-4 py-2 rounded-2xl bg-[#0B1026] border border-violet-500/30 text-xs">
            <span className="text-violet-300 text-[10px] uppercase font-bold block">Total Registrations</span>
            <span className="font-mono-num font-extrabold text-[#F4D06F] text-base">{registrations.length}</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#0B1026]/90 p-5 rounded-3xl border border-violet-500/30 space-y-3 shadow-xl">
        <div className="relative">
          <Search className="w-4 h-4 text-violet-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by Registration ID, student name, register number..."
            className="w-full bg-[#21113D]/40 text-white text-xs rounded-xl pl-10 pr-4 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2 border-t border-violet-500/20">
          <div>
            <label className="block text-[10px] font-bold text-violet-300 uppercase mb-1">Filter by Event</label>
            <select
              value={eventFilter}
              onChange={(e) => setEventFilter(e.target.value)}
              className="w-full bg-[#21113D]/60 text-neutral-200 text-xs rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none truncate font-medium"
            >
              <option value="All">All Events</option>
              {events.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-violet-300 uppercase mb-1">Department</label>
            <select
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value)}
              className="w-full bg-[#21113D]/60 text-neutral-200 text-xs rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-medium"
            >
              {departments.map(d => <option key={d} value={d}>Dept: {d}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-violet-300 uppercase mb-1">Academic Year</label>
            <select
              value={yearFilter}
              onChange={(e) => setYearFilter(e.target.value)}
              className="w-full bg-[#21113D]/60 text-neutral-200 text-xs rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-medium"
            >
              {years.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-violet-300 uppercase mb-1">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full bg-[#21113D]/60 text-neutral-200 text-xs rounded-xl px-3 py-2 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-medium"
            >
              <option value="All">All Statuses</option>
              <option value="PENDING">PENDING</option>
              <option value="APPROVED">APPROVED (CONFIRMED)</option>
              <option value="REJECTED">REJECTED</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#0B1026]/90 rounded-3xl border border-violet-500/30 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-300 min-w-[850px]">
            <thead className="bg-[#21113D]/60 text-[10px] uppercase font-bold text-violet-300 tracking-wider border-b border-violet-500/20">
              <tr>
                <th className="py-3.5 px-4">Registration ID</th>
                <th className="py-3.5 px-4">Student Info</th>
                <th className="py-3.5 px-4">Department & Year</th>
                <th className="py-3.5 px-4">Target Event</th>
                <th className="py-3.5 px-4">Submission Date</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-violet-500/10 font-medium">
              {filtered.map(r => (
                <tr key={r.id} className="hover:bg-violet-950/20 transition-colors">
                  <td className="py-3.5 px-4 font-mono-num font-bold text-fuchsia-400">
                    {r.registrationId}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-extrabold text-white text-sm">{r.studentName}</div>
                    <div className="text-[10px] text-violet-300 font-mono-num">Reg No: {r.registerNumber}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="text-neutral-200 font-semibold">{r.department}</div>
                    <div className="text-[10px] text-neutral-400">{r.year}</div>
                  </td>
                  <td className="py-3.5 px-4 text-neutral-200 max-w-[200px] truncate">
                    {r.eventName}
                  </td>
                  <td className="py-3.5 px-4 text-[11px] text-neutral-400 font-mono-num">
                    {r.registrationDate}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                      r.status === 'APPROVED' 
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40' 
                        : r.status === 'REJECTED'
                        ? 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                        : 'bg-amber-950/80 text-[#F4D06F] border-amber-500/40'
                    }`}>
                      {r.status === 'APPROVED' ? 'CONFIRMED' : r.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {r.status === 'PENDING' && (
                        <>
                          <button
                            onClick={() => approveRegistration(r.id)}
                            className="p-1.5 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/50 transition-colors"
                            title="Approve & Generate Pass"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => rejectRegistration(r.id)}
                            className="p-1.5 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-700/50 transition-colors"
                            title="Reject Registration"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}

                      <button
                        onClick={() => setSelectedDetails(r)}
                        className="p-1.5 rounded-xl bg-[#21113D]/60 hover:bg-[#21113D] text-neutral-200 border border-violet-500/30"
                        title="View Application Details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      {r.status === 'APPROVED' && (
                        <button
                          onClick={() => {
                            setSelectedPassRegistration(r);
                            setCurrentView('digital-pass');
                          }}
                          className="p-1.5 rounded-xl bg-violet-950/60 hover:bg-violet-900 text-[#F4D06F] border border-violet-500/30"
                          title="View Digital Pass"
                        >
                          <Ticket className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        onClick={() => handleDelete(r.id, r.registrationId)}
                        className="p-1.5 rounded-xl bg-[#21113D]/60 hover:bg-rose-950 text-rose-400 border border-violet-500/30 hover:border-rose-500 transition-colors"
                        title="Delete Record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Details Modal */}
      {selectedDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-[#0B1026] border-2 border-violet-500/50 rounded-3xl shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-violet-500/20">
              <div>
                <span className="text-[10px] text-[#F4D06F] font-bold uppercase tracking-wider">Registration Details</span>
                <h3 className="text-base font-extrabold text-white font-mono-num">{selectedDetails.registrationId}</h3>
              </div>
              <button onClick={() => setSelectedDetails(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-[#21113D]/40 p-3.5 rounded-2xl border border-violet-500/20 space-y-1.5">
                <div className="text-[10px] text-violet-400 uppercase font-bold">Student Profile</div>
                <div className="font-extrabold text-white text-sm">{selectedDetails.studentName}</div>
                <div className="text-neutral-300">Reg No: <span className="font-mono-num text-[#F4D06F] font-bold">{selectedDetails.registerNumber}</span></div>
                <div className="text-neutral-300">{selectedDetails.department} • {selectedDetails.year}</div>
                <div className="text-neutral-300">Email: {selectedDetails.email}</div>
                <div className="text-neutral-300">Phone: {selectedDetails.phone}</div>
              </div>

              <div className="bg-[#21113D]/40 p-3.5 rounded-2xl border border-violet-500/20 space-y-1.5">
                <div className="text-[10px] text-violet-400 uppercase font-bold">Event Information</div>
                <div className="font-extrabold text-white">{selectedDetails.eventName}</div>
                <div className="text-[#F4D06F] font-semibold">Scheduled: {selectedDetails.eventDate}</div>
                <div className="text-neutral-300">Venue: {selectedDetails.eventVenue}</div>
                <div className="text-neutral-400 text-[11px] font-mono-num">Submitted: {selectedDetails.registrationDate}</div>
              </div>

              <div className="flex items-center justify-between p-3 bg-[#21113D]/40 rounded-2xl border border-violet-500/20">
                <span className="text-neutral-300">Registration Status:</span>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-black uppercase ${
                  selectedDetails.status === 'APPROVED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40' :
                  selectedDetails.status === 'REJECTED' ? 'bg-rose-950 text-rose-300 border border-rose-500/40' : 'bg-amber-950 text-[#F4D06F] border border-amber-500/40'
                }`}>
                  {selectedDetails.status === 'APPROVED' ? 'CONFIRMED' : selectedDetails.status}
                </span>
              </div>
            </div>

            <div className="pt-2 flex justify-between gap-3 border-t border-violet-500/20">
              <button
                onClick={() => {
                  setSelectedPassRegistration(selectedDetails);
                  setSelectedDetails(null);
                  setCurrentView('digital-pass');
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white text-xs font-bold border border-violet-400/40 shadow-md"
              >
                <Ticket className="w-3.5 h-3.5 text-[#F4D06F]" />
                <span>View Digital Pass</span>
              </button>

              <button
                onClick={() => setSelectedDetails(null)}
                className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-neutral-200 text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
