import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Student } from '../types';
import { 
  Users, UserPlus, Search, Edit2, Trash2, 
  X, Check, Mail, Phone, GraduationCap, ShieldAlert, Sparkles 
} from 'lucide-react';

export const StudentManagementView: React.FC = () => {
  const { students, addStudent, updateStudent, deleteStudent } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [deptFilter, setDeptFilter] = useState('All');
  const [yearFilter, setYearFilter] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    registerNumber: '',
    department: 'ECE',
    year: '2nd Year',
    phone: '',
    email: '',
    gender: 'Male' as 'Male' | 'Female' | 'Other'
  });

  const departments = ['All', 'ECE', 'CSE', 'IT', 'AIDS', 'EEE', 'MECH', 'CIVIL'];
  const years = ['All', '1st Year', '2nd Year', '3rd Year', '4th Year'];

  const handleOpenAdd = () => {
    setEditingStudent(null);
    setFormData({
      name: '',
      registerNumber: '92252510' + Math.floor(1000 + Math.random() * 9000),
      department: 'ECE',
      year: '2nd Year',
      phone: '98' + Math.floor(10000000 + Math.random() * 90000000),
      email: '',
      gender: 'Male'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (stu: Student) => {
    setEditingStudent(stu);
    setFormData({
      name: stu.name,
      registerNumber: stu.registerNumber,
      department: stu.department,
      year: stu.year,
      phone: stu.phone,
      email: stu.email,
      gender: stu.gender
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.registerNumber.trim() || !formData.email.trim()) {
      alert('Please fill all mandatory fields.');
      return;
    }

    if (editingStudent) {
      updateStudent(editingStudent.id, formData);
    } else {
      addStudent(formData);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Remove student "${name}" from portal records?`)) {
      deleteStudent(id);
    }
  };

  const filtered = students.filter(s => {
    const matchesSearch = 
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.registerNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = deptFilter === 'All' || s.department === deptFilter;
    const matchesYear = yearFilter === 'All' || s.year === yearFilter;
    return matchesSearch && matchesDept && matchesYear;
  });

  return (
    <div className="space-y-6 pb-16">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] p-6 rounded-3xl border border-violet-500/30 shadow-xl">
        <div>
          <span className="text-[10px] font-bold text-[#F4D06F] uppercase tracking-widest flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#F4D06F]" />
            <span>STUDENT DIRECTORY • VSBEC EVENTVERSE</span>
          </span>
          <h1 className="text-2xl font-black text-white font-heading mt-1">
            Student Management System
          </h1>
          <p className="text-xs text-neutral-300 mt-1">
            Maintain verified student credentials, college register numbers, and participation history for V.S.B. Engineering College.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] hover:from-[#6D28D9] hover:to-[#A21CAF] text-white font-extrabold text-xs uppercase tracking-wider shadow-xl shadow-violet-900/50 border border-violet-400/40 hover:scale-105 transition-all self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4 text-[#F4D06F]" />
          <span>Add New Student</span>
        </button>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-violet-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by student name, register number, email..."
            className="w-full bg-[#0B1026] text-white text-xs rounded-xl pl-10 pr-4 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
          />
        </div>

        <select
          value={deptFilter}
          onChange={(e) => setDeptFilter(e.target.value)}
          className="bg-[#0B1026] text-neutral-200 text-xs rounded-xl px-4 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-semibold"
        >
          {departments.map(d => <option key={d} value={d}>Dept: {d}</option>)}
        </select>

        <select
          value={yearFilter}
          onChange={(e) => setYearFilter(e.target.value)}
          className="bg-[#0B1026] text-neutral-200 text-xs rounded-xl px-4 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-semibold"
        >
          {years.map(y => <option key={y} value={y}>{y}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="bg-[#0B1026]/90 rounded-3xl border border-violet-500/30 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-300 min-w-[750px]">
            <thead className="bg-[#21113D]/60 text-[10px] uppercase font-bold text-violet-300 tracking-wider border-b border-violet-500/20">
              <tr>
                <th className="py-3.5 px-4">Student ID</th>
                <th className="py-3.5 px-4">Name & Register Number</th>
                <th className="py-3.5 px-4">Department & Year</th>
                <th className="py-3.5 px-4">Contact Info</th>
                <th className="py-3.5 px-4">Gender</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-violet-500/10">
              {filtered.map(stu => (
                <tr key={stu.id} className="hover:bg-violet-950/20 transition-colors">
                  <td className="py-3.5 px-4 font-mono-num font-bold text-[#F4D06F]">
                    {stu.studentId}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-extrabold text-white text-sm">{stu.name}</div>
                    <div className="text-[11px] text-violet-300 font-mono-num">Reg No: {stu.registerNumber}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-neutral-200">Dept of {stu.department}</div>
                    <div className="text-[10px] text-neutral-400">{stu.year}</div>
                  </td>
                  <td className="py-3.5 px-4 space-y-0.5">
                    <div className="text-neutral-300">{stu.email}</div>
                    <div className="text-[10px] text-violet-400 font-mono-num">{stu.phone}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-full bg-violet-950/80 text-violet-200 text-[10px] border border-violet-500/30 font-semibold">
                      {stu.gender}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleOpenEdit(stu)}
                        className="p-1.5 rounded-xl bg-[#21113D]/60 hover:bg-[#21113D] text-[#F4D06F] border border-violet-500/30 transition-colors"
                        title="Edit Student"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(stu.id, stu.name)}
                        className="p-1.5 rounded-xl bg-[#21113D]/60 hover:bg-rose-950 text-rose-400 border border-violet-500/30 hover:border-rose-500 transition-colors"
                        title="Delete Student"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Student Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg bg-[#0B1026] border-2 border-violet-500/50 rounded-3xl shadow-2xl overflow-hidden my-8">
            
            <div className="bg-gradient-to-r from-[#21113D] via-[#0B1026] to-[#21113D] px-6 py-4 border-b border-violet-500/30 flex items-center justify-between">
              <div>
                <h3 className="text-base font-extrabold text-white font-heading">
                  {editingStudent ? 'Edit Student Record' : 'Enroll New Student'}
                </h3>
                <span className="text-[11px] text-[#F4D06F] font-bold">
                  V.S.B. Engineering College, Karur • VSBEC EVENTVERSE
                </span>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-1.5 text-neutral-400 hover:text-white rounded-xl">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">Student Full Name *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Karthik Raja S"
                  className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Register Number *</label>
                  <input
                    type="text"
                    required
                    value={formData.registerNumber}
                    onChange={(e) => setFormData({ ...formData, registerNumber: e.target.value })}
                    placeholder="922525106012"
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-mono-num"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Gender *</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Department *</label>
                  <select
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  >
                    {departments.filter(d => d !== 'All').map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Class / Year *</label>
                  <select
                    value={formData.year}
                    onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  >
                    {years.filter(y => y !== 'All').map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="9843212345"
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none font-mono-num"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-300 mb-1">College Email *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="karthik.ece@vsbec.ac.in"
                    className="w-full bg-[#21113D]/60 text-white rounded-xl px-3 py-2.5 border border-violet-500/30 focus:border-[#F4D06F] outline-none"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-3 border-t border-violet-500/20">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#C026D3] to-[#7C3AED] text-white font-bold uppercase tracking-wider border border-violet-400/40 shadow-md shadow-violet-950"
                >
                  {editingStudent ? 'Update Record' : 'Save Student'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
